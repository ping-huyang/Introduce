#include "zf_common_headfile.h"

/********************************************************************
* @brief    : 下位机控制，主循环处理接受上位机指令，20ms中断刷新电机调速 
* @daily    : ~3.22 完成直流电机闭环速控、舵机调节、基本上位机通信调节
* @daily    : 3.23  增加了按键调节PID的控制，在初始化加入ChangePID_KEY_Init，
                    循环里加入ChangePID_KEY即可
              3.25  串口通信协议初始编写，匿名助手显示波形暂时不行
              3.26  基本的串口通信协议写好，测试还行，匿名助手波形显示成功
              4.2   优化了下位机和下位机通信，将处理移到了中断里面
              4.6   整体代码优化改进，PID模型处进行大幅度修改
              4.8   添加了z轴角速度十次滤波，添加了计时和flash存储功能
              4.10  添加了基本的转向角度检测代码，设置转向角度，当到达将
                    相应的标志位变量变为true，缺点就是必须确保设置的角度
                    准确，可能需要进行错误处理，时长检测等
              4.18  改进了按键实现程序，移植正点原子按键扫描程序，设置为
                    按键回调功能。
              4.25  更换小屏幕作为主要的参数显示部件，添加了拨码开关的模式
                    判断和两个按键扫描控制。
              4.26  完成BIM088六轴加速度陀螺仪得初始化数据读取，和基本的
                    功能测试，能够实现角度测量和角加速度
              4.27  测试了BIM088和MPU660RA，对比了一下两者的效果
              4.29  完成舵机串级pid内环控制，完成按键修改pid值
              5.1   完成USB通信功能，添加显示三种通信接收数据和成功处理的
                    次数统计
              6.6   硬件变成四个按键
              6.10  添加上坡坡道控制、断路控制、出库入库控制
              7.10  修改添加很多附属功能，完善了很懂东西
* @note     : 2023/03/22 16:56:26
********************************************************************/

int main (void)
{
    clock_init(SYSTEM_CLOCK_600M);                  //系统时钟初始化    
    debug_init();                                   //Debug模式，调试使用
    Variable_Init();                                //部分路段参数设置
    timer_init(GPT_TIM_1, TIMER_MS);                //定时器计时，调试使用
    // Isp114_Init();                                  //小屏幕显示初始化
    MOTOR_Init();                                   //直流电机初始化
    imu660ra_init();                                //IMU660RA六轴陀螺仪加速度初始化
    SERVO_Init();                                   //舵机初始化
    Buzzer_Init();                                  //蜂鸣器初始化
    USART_Init();                                   //串口1通信初始化
    KEY_Scan3_Init();                               //按键初始化
    // wrilessUrat_Init();                             //无线串口初始化，调试显示波形使用
    // adc_init(ADC_BATTERY_CH, ADC_12BIT);            //ADC引脚检测电压值
    TIMER_Init();                                   //定时器中断初始化
    system_delay_ms(500);                           //初始化延时

    while(1)
    {
        //四个拨码开关和两个按键，按键扫描，模式判断
        keyNum = KEY_Scan3(0);
        if (keyNum >= 1 && keyNum <= keyFuncNumbers) {
            keyWorkFunc[keyNum - 1]();
        }
    
        // //刷新小屏幕页面显示
        // OLED_RefshShow();

        //匿名助手显示int16类型数据
        // Display_Int16Img();   
        //匿名助手显示float数据波形        
        // Display_FloatImg(); 
    }
}

// // 电池电压检测
// if(Battery.Deal){
//     Battery.Deal = 0;
//     Battery.Value = adc_mean_filter_convert(ADC_BATTERY_CH, 10);
//     printf("ADC_Battery_Filter : %d.\r\n",Battery.Value);
//     if(Battery.Value <= 3500){
//         Battery.Buzzer_Ring_Flag = 1;
//     }
// }

// // 电压过低报警
// if(Battery.Buzzer_Ring_Flag && !Battery.Times2) Buzzer_Toggle();

