#include "pid.h"

/*************************************************************************************
* @note    : ���PID���� 
* @note    : none 
* @note    : none 
* @note    : none
* @time     : 2023/04/29 09:36:43
*************************************************************************************/
// ���Ƶ��ת�ٵ�pid
PID1 motor_pid;

void MotorPID_Init(void)
{
    memset(&motor_pid, 0, sizeof(motor_pid));
    motor_pid.kp = MOTORPID_ORIGINE_KP;
    motor_pid.kd = MOTORPID_ORIGINE_KD;
    motor_pid.ki_1 = MOTORPID_ORIGINE_KI1;
    motor_pid.ki_2 = MOTORPID_ORIGINE_KI2;
}

/**
* @brief    : ֱ���������ʽPID 
* @param    : PID�ṹ�壬��������������
* @return   : ���ؾ���PID������PWM����ֵ 
* @author   : HuQingpei
* @note     : 2023/04/06 14:48:15
**/
int16 MotorPID_Calc(PID1* pid)
{
    static float abs_error;
    //���͵�����ʽPID����ģ��
    pid->lastlastError = pid->lastError;
    pid->lastError = pid->error;
    pid->error = pid->input - pid->feedback;
    abs_error = (float)fabs(pid->error);
   if(!((abs_error < MOTORPID_VV_DEADLINE )))
   {
        pid->ki = abs_error * pid->ki_2 + pid->ki_1;
        pid->output += pid->kp*(pid->error - pid->lastError) + pid->ki*pid->error + pid->kd*(pid->error - 2*pid->lastError + pid->lastlastError);
   }
    if(pid->output > MOTOR_PWM_MAX)
        pid->output = MOTOR_PWM_MAX;
    if(pid->output < -MOTOR_PWM_MAX)
        pid->output = -MOTOR_PWM_MAX;
    return pid->output;
}



/*************************************************************************************
* @note    : ���PID���� 
* @note    : none 
* @note    : none 
* @note    : none
* @time     : 2023/04/29 09:36:36
*************************************************************************************/
// ǰ����ת����pid��������ֱ�߶��pid
PID  servo_pid,servo_line_pid;

void ServoPID_Init(void)
{
    memset(&servo_pid, 0, sizeof(servo_pid));
    memset(&servo_line_pid, 0, sizeof(servo_line_pid));
    servo_pid.kp = SERVOPID_ORIGINE_KP;
    servo_pid.ki = SERVOPID_ORIGINE_KI;
    servo_line_pid.kp = SERVOPID_LINE_ORIGINE_KP;
    servo_line_pid.ki = SERVOPID_LINE_ORIGINE_KI;
}

void ServoPID_Clear(void)
{
    ServoPID_Init();
}


/**
* @brief    : ת����pid���� 
* @param    : none 
* @return   : none 
* @author   : HuQingpei
* @note     : 2023/04/30 10:13:12
**/
int16 ServoPID_Turn_Calc(PID *pid)
{
    pid->lastError = pid->error;
    pid->error = pid->input - pid->feedback;
    if(!((pid->error < SERVOPID_VV_DEADLINE )&&(pid->error > -SERVOPID_VV_DEADLINE)))
    {
        if(motor_pid.feedback > 0){
            pid->output += -pid->kp*(pid->error - pid->lastError) - pid->ki*pid->error;
        }
        if(motor_pid.feedback < 0){
            pid->output += pid->kp*(pid->error - pid->lastError) + pid->ki*pid->error;
        }
    }
    if(pid->output > 400)
        pid->output = 400;
    if(pid->output < -400)
        pid->output = -400;
    return pid->output;
}


/**
* @brief    : ֱ�߶��pid���� 
* @param    : none 
* @return   : none 
* @author   : HuQingpei
* @note     : 2023/04/30 10:13:16
**/
int16 ServoPID_Line_Calc(PID *pid)
{
    pid->lastError = pid->error;
    pid->error = servo_pid.input - servo_pid.feedback;
    if(motor_pid.feedback > 0){
        pid->output += -pid->kp*(pid->error - pid->lastError) - pid->ki*pid->error;
    }
    if(motor_pid.feedback < 0){
        pid->output += pid->kp*(pid->error - pid->lastError) + pid->ki*pid->error;
    }
    if(pid->output > 400)
        pid->output = 400;
    if(pid->output < -400)
        pid->output = -400;
    return pid->output;
}


/**
* @brief    : ��λ��������Ȼ�����pid���Ƽ���
* @param    : none 
* @return   : none 
* @author   : HuQingpei
* @note     : 2023/06/08 10:38:07
**/
#define COLSIMAGE 160
float error = 0, turnP = 0, runP1 = SERVO_ERROR_KP1, runP2 = SERVO_ERROR_KP2, turnD = SERVO_ERROR_KD;
void pdController(void)
{
	static int errorLast = 0; // ��¼ǰһ�ε�ƫ��
	if (fabs(error - errorLast) > COLSIMAGE / 10){
		error = error > errorLast ? errorLast + COLSIMAGE / 10 : errorLast - COLSIMAGE / 10;
	}
	turnP = fabs(error) * runP2 + runP1;
	int pwmDiff = (error * turnP) + (error - errorLast) * turnD;
	errorLast = error;
	Servo_SetPWM_Value = (uint16_t)(SERVO_PWM_MIDDLE + pwmDiff); 
}

