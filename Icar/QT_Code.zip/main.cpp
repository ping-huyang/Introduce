#include "mainwindow.h"

#include <QApplication>
#include <QFile>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    // 加载QSS文件
    QFile file(":/res/qss/ubuntu.qss");
    file.open(QFile::ReadOnly);
    QString qss = QString::fromLatin1(file.readAll());
    file.close();
    a.setStyleSheet(qss);
    MainWindow w;
    w.show();
    return a.exec();
}
