#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QThread>

// 创建串口对象
QSerialPort serial;

// 获取可用的串口列表
QList<QSerialPortInfo> portList = QSerialPortInfo::availablePorts();

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setWindowIcon(QIcon(":/res/ICON.ico"));
    setFixedSize(1500,835);
    this->setWindowTitle("ICar_Usart_version 2.0");
    MainWindow::on_pushButton_20_clicked();
}

MainWindow::~MainWindow()
{
    delete ui;
}

//打开串口按钮回调函数
void MainWindow::on_pushButton_15_clicked()
{
    m_serial.setPortName(ui->comboBox->currentText());
    m_serial.setBaudRate(ui->comboBox_2->currentText().toInt());
    m_serial.open(QIODevice::ReadWrite);

    if(m_serial.isOpen()){
        ui->state->setText("串口打开成功");
        ui->plainTextEdit->clear();
        ui->plainTextEdit->insertPlainText("串口打开成功");
        connect(&m_serial,&QSerialPort::readyRead,this,&MainWindow::messlot);
    }else {
        ui->state->setText("串口打开失败");
        ui->plainTextEdit->clear();
        ui->plainTextEdit->insertPlainText("串口打开失败");
    }
}

//关闭串口按钮回调函数
void MainWindow::on_pushButton_19_clicked()
{
    m_serial.close();
    if(m_serial.isOpen()){
        ui->state->setText("串口关闭失败");
        ui->plainTextEdit->clear();
        ui->plainTextEdit->insertPlainText("串口关闭失败");
    }else {
        ui->state->setText("串口关闭成功");
        ui->plainTextEdit->clear();
        ui->plainTextEdit->insertPlainText("串口关闭成功");
    }
}

//刷新串口按钮回调函数
void MainWindow::on_pushButton_20_clicked()
{
    ui->comboBox->clear();
    foreach(const QSerialPortInfo &info,QSerialPortInfo::availablePorts())
    {
        ui->comboBox->addItem(info.portName());
    }
}

//串口接收信息的处理函数
void MainWindow::messlot()
{
    QByteArray array = m_serial.readAll();
    ui->plainTextEdit->insertPlainText(array);
}

//清空接收框的信息
void MainWindow::on_pushButton_clicked()
{
    ui->plainTextEdit->clear();
}

//清空发送框中的信息
void MainWindow::on_pushButton_2_clicked()
{
    ui->plainTextEdit_2->clear();
}

//发送数据回调函数
void MainWindow::on_pushButton_3_clicked()
{
    QByteArray array2 = ui->plainTextEdit_2->toPlainText().toUtf8();
    m_serial.write(array2);
}

int16Bytes speed1;

//设定电机转动参数
void MainWindow::setMotorSpeed(int16_t speed)
{
    uint8_t result[] = {0xAB , 0xD2, 0x02, 0x00, 0x00, 0x00};
    uint8_t sumcheck = 0;
    speed1.int16bit = speed;
    result[3] = speed1.b[1];
    result[4] = speed1.b[0];
    for(uint8_t i=0; i < (result[2]+3); i++)
    {
        sumcheck += result[i];
    }
    result[5] = sumcheck;
    qint64 bytesWritten = m_serial.write(reinterpret_cast<char*>(result), sizeof(result));
    if (bytesWritten == -1) {
        ui->plainTextEdit->clear();
        ui->plainTextEdit->insertPlainText("出错了~设定失败~");
    } else {
        ui->plainTextEdit->clear();
        ui->plainTextEdit->insertPlainText("设置电机速度成功！！！");
    }
}

//设定舵机PWM值
void MainWindow::setServoPWM(uint16_t servoPwm)
{
    uint8_t result[] = {0xAB , 0xC1, 0x02, 0x00, 0x00, 0x00};
    uint8_t sumcheck = 0;
    speed1.int16bit = servoPwm;
    result[3] = speed1.b[1];
    result[4] = speed1.b[0];
    for(uint8_t i=0; i < (result[2]+3); i++)
    {
        sumcheck += result[i];
    }
    result[5] = sumcheck;
    qint64 bytesWritten = m_serial.write(reinterpret_cast<char*>(result), sizeof(result));
    if (bytesWritten == -1) {
        ui->plainTextEdit->clear();
        ui->plainTextEdit->insertPlainText("出错了~设定失败~");
    } else {
        ui->plainTextEdit->clear();
        ui->plainTextEdit->insertPlainText("设置舵机PWM成功！！！");
    }
}

void MainWindow::buzzerRing(void)
{
    uint8_t result[] = {0xAB , 0xE3, 0x01, 0x01, 0x00};
    uint8_t sumcheck = 0;
    for(uint8_t i=0; i < (result[2]+3); i++)
    {
        sumcheck += result[i];
    }
    result[4] = sumcheck;
    qint64 bytesWritten = m_serial.write(reinterpret_cast<char*>(result), sizeof(result));
    if (bytesWritten == -1) {
        ui->plainTextEdit->clear();
        ui->plainTextEdit->insertPlainText("出错了~设定失败~");
    } else {
        ui->plainTextEdit->clear();
        ui->plainTextEdit->insertPlainText("蜂鸣器响一声OK");
    }
}

FloatBytes fb1,fb2,fb3,fb4;

//设定电机PID参数
void MainWindow::setMotorPID(float kp,float ki1, float ki2 ,float kd)
{
    uint8_t result[] = {0xAB , 0xF4, 0x0C, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
    uint8_t sumcheck = 0;
    fb1.f = kp;
    fb2.f = ki1;
    fb3.f = ki2;
    fb4.f = kd;
    result[3] = fb1.b[3];result[4] = fb1.b[2];result[5] = fb1.b[1];result[6] = fb1.b[0];
    result[7] = fb2.b[3];result[8] = fb2.b[2];result[9] = fb2.b[1];result[10] = fb2.b[0];
    result[11] = fb3.b[3];result[12] = fb3.b[2];result[13] = fb3.b[1];result[14] = fb3.b[0];
    result[15] = fb4.b[3];result[16] = fb4.b[2];result[17] = fb4.b[1];result[18] = fb4.b[0];
    for(uint8_t i=0; i < (result[2]+3); i++)
    {
        sumcheck += result[i];
    }
    result[19] = sumcheck;
    qint64 bytesWritten = m_serial.write(reinterpret_cast<char*>(result), sizeof(result));
    if (bytesWritten == -1) {
        ui->plainTextEdit->clear();
        ui->plainTextEdit->insertPlainText("出错了~设定失败~");
    } else {
        ui->plainTextEdit->clear();
        ui->plainTextEdit->insertPlainText("电机PID参数修改成功~~~");
    }
}

void MainWindow::setServoPID(float kp,float ki, float kd)
{
    uint8_t result[] = {0xAB , 0xF7, 0x0C, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
    uint8_t sumcheck = 0;
    fb1.f = kp;
    fb2.f = ki;
    fb3.f = kd;
    result[3] = fb1.b[3];result[4] = fb1.b[2];result[5] = fb1.b[1];result[6] = fb1.b[0];
    result[7] = fb2.b[3];result[8] = fb2.b[2];result[9] = fb2.b[1];result[10] = fb2.b[0];
    result[11] = fb3.b[3];result[12] = fb3.b[2];result[13] = fb3.b[1];result[14] = fb3.b[0];
    for(uint8_t i=0; i < (result[2]+3); i++)
    {
        sumcheck += result[i];
    }
    result[15] = sumcheck;
    qint64 bytesWritten = m_serial.write(reinterpret_cast<char*>(result), sizeof(result));
    if (bytesWritten == -1) {
        ui->plainTextEdit->clear();
        ui->plainTextEdit->insertPlainText("出错了~设定失败~");
    } else {
        ui->plainTextEdit->clear();
        ui->plainTextEdit->insertPlainText("舵机外环PID修改成功~~~");
    }
}

void MainWindow::setServoBendPI(float kp,float ki)
{
    uint8_t result[] = {0xAB , 0xF6, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
    uint8_t sumcheck = 0;
    fb1.f = kp;
    fb2.f = ki;
    result[3] = fb1.b[3];result[4] = fb1.b[2];result[5] = fb1.b[1];result[6] = fb1.b[0];
    result[7] = fb2.b[3];result[8] = fb2.b[2];result[9] = fb2.b[1];result[10] = fb2.b[0];
    for(uint8_t i=0; i < (result[2]+3); i++)
    {
        sumcheck += result[i];
    }
    result[11] = sumcheck;
    qint64 bytesWritten = m_serial.write(reinterpret_cast<char*>(result), sizeof(result));
    if (bytesWritten == -1) {
        ui->plainTextEdit->clear();
        ui->plainTextEdit->insertPlainText("出错了~设定失败~");
    } else {
        ui->plainTextEdit->clear();
        ui->plainTextEdit->insertPlainText("舵机内环转向PI设置成功~~~");
    }
}

void MainWindow::setServoLinePI(float kp,float ki)
{
    uint8_t result[] = {0xAB , 0xF5, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
    uint8_t sumcheck = 0;
    fb1.f = kp;
    fb2.f = ki;
    result[3] = fb1.b[3];result[4] = fb1.b[2];result[5] = fb1.b[1];result[6] = fb1.b[0];
    result[7] = fb2.b[3];result[8] = fb2.b[2];result[9] = fb2.b[1];result[10] = fb2.b[0];
    for(uint8_t i=0; i < (result[2]+3); i++)
    {
        sumcheck += result[i];
    }
    result[11] = sumcheck;
    qint64 bytesWritten = m_serial.write(reinterpret_cast<char*>(result), sizeof(result));
    if (bytesWritten == -1) {
        ui->plainTextEdit->clear();
        ui->plainTextEdit->insertPlainText("出错了~设定失败~");
    } else {
        ui->plainTextEdit->clear();
        ui->plainTextEdit->insertPlainText("舵机内环直线PI设置成功~~~");
    }
}


//设置电机速度为-300
void MainWindow::on_pushButton_16_clicked()
{
    MainWindow::setMotorSpeed(-300);
    ui->plainTextEdit->insertPlainText("速度：-300");
}

//设置电机速度为0
void MainWindow::on_pushButton_17_clicked()
{
    MainWindow::setMotorSpeed(0);
    ui->plainTextEdit->insertPlainText("速度：0");
}

//设计电机速度为300
void MainWindow::on_pushButton_18_clicked()
{
    MainWindow::setMotorSpeed(300);
    ui->plainTextEdit->insertPlainText("速度：300");
}

//设置自定义电机转速1
void MainWindow::on_pushButton_6_clicked()
{
    MainWindow::setMotorSpeed(static_cast<int16_t>(ui->lineEdit_3->text().toInt()));
}

//设置自定义电机转速2
void MainWindow::on_pushButton_5_clicked()
{
    MainWindow::setMotorSpeed(static_cast<int16_t>(ui->lineEdit_2->text().toInt()));
}

//设置自定义电机转速3
void MainWindow::on_pushButton_4_clicked()
{
    MainWindow::setMotorSpeed(static_cast<int16_t>(ui->lineEdit->text().toInt()));
}


//设置舵机最左
void MainWindow::on_pushButton_10_clicked()
{
    MainWindow::setServoPWM(1150);
    ui->plainTextEdit->insertPlainText("最左");
}

//设置舵机居中
void MainWindow::on_pushButton_9_clicked()
{
    MainWindow::setServoPWM(1500);
    ui->plainTextEdit->insertPlainText("居中");
}

//设置舵机最右
void MainWindow::on_pushButton_8_clicked()
{
    MainWindow::setServoPWM(1850);
    ui->plainTextEdit->insertPlainText("最右");
}

//设置舵机为自定义的PWM
void MainWindow::on_pushButton_7_clicked()
{
    MainWindow::setServoPWM(static_cast<int16_t>(ui->lineEdit_4->text().toInt()));
    ui->plainTextEdit->insertPlainText("自定义");
}

//修改电机PID参数
void MainWindow::on_pushButton_11_clicked()
{
    MainWindow::setMotorPID(ui->lineEdit_7->text().toFloat(),ui->lineEdit_5->text().toFloat(),ui->lineEdit_20->text().toFloat(),ui->lineEdit_8->text().toFloat());
}


//控制蜂鸣器发声音
void MainWindow::on_pushButton_21_clicked()
{
    MainWindow::buzzerRing();
}


//开始测试
void MainWindow::on_pushButton_14_clicked()
{
    uint8_t result[] = {0xAB,0xC3,0x09,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
    uint8_t sumcheck = 0;
    result[3] = 0x01;
    fb1.f = ui->lineEdit_15->text().toFloat();
    fb2.f = ui->lineEdit_16->text().toFloat();;
    result[4] = fb1.b[3];result[5] = fb1.b[2];result[6] = fb1.b[1];result[7] = fb1.b[0];
    result[8] = fb2.b[3];result[9] = fb2.b[2];result[10] = fb2.b[1];result[11] = fb2.b[0];
    for(uint8_t i=0; i < (result[2]+3); i++)
    {
        sumcheck += result[i];
    }
    result[12] = sumcheck;
    qint64 bytesWritten = m_serial.write(reinterpret_cast<char*>(result), sizeof(result));
    if (bytesWritten == -1) {
        ui->plainTextEdit->clear();
        ui->plainTextEdit->insertPlainText("设定失败~~");
    } else {
        ui->plainTextEdit->clear();
        ui->plainTextEdit->insertPlainText("设定成功~~~");
    }
}

//停止测试
void MainWindow::on_pushButton_25_clicked()
{
    uint8_t result[] = {0xAB ,0xC3,0x09,0x00,0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
    uint8_t sumcheck = 0;
    result[3] = 0x00;
    for(uint8_t i=0; i < (result[2]+3); i++)
    {
        sumcheck += result[i];
    }
    result[12] = sumcheck;
    qint64 bytesWritten = m_serial.write(reinterpret_cast<char*>(result), sizeof(result));

    if (bytesWritten == -1) {
        ui->plainTextEdit->clear();
        ui->plainTextEdit->insertPlainText("设定失败~~");
    } else {
        ui->plainTextEdit->clear();
        ui->plainTextEdit->insertPlainText("设定成功~~~");
    }
}

// 停车测试
void MainWindow::parking(uint8_t commond)
{
    uint8_t result[] = {0xAB , 0xB1, 0x01, 0x00, 0x00};
    uint8_t sumcheck = 0;
    result[3] = commond;
    for(uint8_t i=0; i < (result[2]+3); i++)
    {
        sumcheck += result[i];
    }
    result[4] = sumcheck;
    qint64 bytesWritten = m_serial.write(reinterpret_cast<char*>(result), sizeof(result));
    if (bytesWritten == -1) {
        ui->plainTextEdit->clear();
        ui->plainTextEdit->insertPlainText("出错了~设定失败~");
    } else {
        ui->plainTextEdit->clear();
        ui->plainTextEdit->insertPlainText("蜂鸣器响一声OK");
    }
}

// 侧方位测试
void MainWindow::on_pushButton_68_clicked()
{
    parking(1);
}

// 入库测试
void MainWindow::on_pushButton_69_clicked()
{
    parking(3);
}

// 出库测试
void MainWindow::on_pushButton_70_clicked()
{
    parking(2);
}

// 复位停车
void MainWindow::on_pushButton_75_clicked()
{
    parking(0);
    QThread::msleep(200);
    on_pushButton_17_clicked();
}

FloatBytes error_vab;
// 向下位机发送误差
void MainWindow::on_pushButton_24_clicked()
{
    uint8_t result[] = {0xAB , 0xC2, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00};
    uint8_t sumcheck = 0;
    error_vab.f = (ui->lineEdit_19->text().toFloat());
    qDebug() << "error_vab.f is : " << error_vab.f << endl;
    result[3] = error_vab.b[3];
    result[4] = error_vab.b[2];
    result[5] = error_vab.b[1];
    result[6] = error_vab.b[0];
    for(uint8_t i=0; i < (result[2]+3); i++)
    {
        sumcheck += result[i];
    }
    result[7] = sumcheck;
    qint64 bytesWritten = m_serial.write(reinterpret_cast<char*>(result), sizeof(result));
    if (bytesWritten == -1) {
        ui->plainTextEdit->clear();
        ui->plainTextEdit->insertPlainText("出错了~设定失败~");
    } else {
        ui->plainTextEdit->clear();
        ui->plainTextEdit->insertPlainText("设置误差成功: " + QString::number(error_vab.f));
    }
}

//修改动作参数
void MainWindow::on_pushButton_13_clicked()
{
    uint8_t result[] = {0xAB , 0xB2, 0x0D, 0x00, 0x00};
    uint8_t sumcheck = 0;
    result[3] = commond;
    for(uint8_t i=0; i < (result[2]+3); i++)
    {
        sumcheck += result[i];
    }
    result[4] = sumcheck;
    qint64 bytesWritten = m_serial.write(reinterpret_cast<char*>(result), sizeof(result));
    if (bytesWritten == -1) {
        ui->plainTextEdit->clear();
        ui->plainTextEdit->insertPlainText("出错了~设定失败~");
    } else {
        ui->plainTextEdit->clear();
        ui->plainTextEdit->insertPlainText("蜂鸣器响一声OK");
    }
}
