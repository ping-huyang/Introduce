/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QGridLayout *gridLayout;
    QVBoxLayout *verticalLayout_2;
    QLabel *state;
    QSpacerItem *horizontalSpacer;
    QHBoxLayout *horizontalLayout_14;
    QLabel *label_14;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_15;
    QHBoxLayout *horizontalLayout_5;
    QLineEdit *lineEdit_7;
    QLineEdit *lineEdit_5;
    QLineEdit *lineEdit_20;
    QLineEdit *lineEdit_8;
    QPushButton *pushButton_11;
    QHBoxLayout *horizontalLayout_17;
    QLabel *label_18;
    QLabel *label_8;
    QLabel *label_19;
    QLabel *label_20;
    QHBoxLayout *horizontalLayout_16;
    QLineEdit *lineEdit_9;
    QLineEdit *lineEdit_6;
    QLineEdit *lineEdit_10;
    QLineEdit *lineEdit_21;
    QHBoxLayout *horizontalLayout_19;
    QLabel *label_9;
    QLabel *label_21;
    QLabel *label_28;
    QHBoxLayout *horizontalLayout_18;
    QLineEdit *lineEdit_11;
    QLineEdit *lineEdit_12;
    QLineEdit *lineEdit_13;
    QPushButton *pushButton_13;
    QHBoxLayout *horizontalLayout_25;
    QLabel *label_22;
    QLabel *label_23;
    QLabel *label_24;
    QHBoxLayout *horizontalLayout_20;
    QLineEdit *lineEdit_14;
    QLineEdit *lineEdit_15;
    QLineEdit *lineEdit_16;
    QPushButton *pushButton_14;
    QPushButton *pushButton_25;
    QHBoxLayout *horizontalLayout_48;
    QPushButton *pushButton_68;
    QPushButton *pushButton_69;
    QPushButton *pushButton_70;
    QHBoxLayout *horizontalLayout_50;
    QPushButton *pushButton_75;
    QHBoxLayout *horizontalLayout_35;
    QPushButton *pushButton_42;
    QPushButton *pushButton_43;
    QPushButton *pushButton_44;
    QHBoxLayout *horizontalLayout_36;
    QPushButton *pushButton_45;
    QPushButton *pushButton_46;
    QPushButton *pushButton_47;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *pushButton_15;
    QPushButton *pushButton_19;
    QPushButton *pushButton_20;
    QLabel *label;
    QPlainTextEdit *plainTextEdit;
    QPushButton *pushButton;
    QLabel *label_2;
    QPlainTextEdit *plainTextEdit_2;
    QHBoxLayout *horizontalLayout;
    QPushButton *pushButton_3;
    QPushButton *pushButton_2;
    QVBoxLayout *verticalLayout_3;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_4;
    QComboBox *comboBox;
    QLabel *label_5;
    QComboBox *comboBox_2;
    QSpacerItem *horizontalSpacer_2;
    QHBoxLayout *horizontalLayout_11;
    QLabel *label_12;
    QLineEdit *lineEdit_3;
    QPushButton *pushButton_6;
    QHBoxLayout *horizontalLayout_10;
    QLabel *label_11;
    QLineEdit *lineEdit_2;
    QPushButton *pushButton_5;
    QHBoxLayout *horizontalLayout_9;
    QLabel *label_10;
    QLineEdit *lineEdit;
    QPushButton *pushButton_4;
    QHBoxLayout *horizontalLayout_21;
    QPushButton *pushButton_16;
    QPushButton *pushButton_17;
    QPushButton *pushButton_18;
    QHBoxLayout *horizontalLayout_12;
    QLabel *label_13;
    QLineEdit *lineEdit_4;
    QPushButton *pushButton_7;
    QHBoxLayout *horizontalLayout_22;
    QLabel *label_25;
    QLineEdit *lineEdit_17;
    QPushButton *pushButton_22;
    QHBoxLayout *horizontalLayout_23;
    QLabel *label_26;
    QLineEdit *lineEdit_18;
    QPushButton *pushButton_23;
    QHBoxLayout *horizontalLayout_24;
    QLabel *label_27;
    QLineEdit *lineEdit_19;
    QPushButton *pushButton_24;
    QHBoxLayout *horizontalLayout_13;
    QPushButton *pushButton_10;
    QPushButton *pushButton_9;
    QPushButton *pushButton_8;
    QPushButton *pushButton_21;
    QHBoxLayout *horizontalLayout_52;
    QPushButton *pushButton_80;
    QPushButton *pushButton_81;
    QPushButton *pushButton_82;
    QHBoxLayout *horizontalLayout_34;
    QPushButton *pushButton_39;
    QPushButton *pushButton_40;
    QPushButton *pushButton_41;
    QHBoxLayout *horizontalLayout_37;
    QPushButton *pushButton_48;
    QPushButton *pushButton_49;
    QPushButton *pushButton_50;
    QHBoxLayout *horizontalLayout_38;
    QPushButton *pushButton_51;
    QPushButton *pushButton_52;
    QPushButton *pushButton_53;
    QMenuBar *menubar;
    QMenu *menu;
    QMenu *menu_2;
    QMenu *menu_3;
    QMenu *menu_4;
    QMenu *menu_5;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(1342, 805);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        centralwidget->setEnabled(true);
        gridLayout = new QGridLayout(centralwidget);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        state = new QLabel(centralwidget);
        state->setObjectName(QStringLiteral("state"));
        state->setMinimumSize(QSize(0, 50));
        state->setMaximumSize(QSize(16777215, 50));

        verticalLayout_2->addWidget(state);

        horizontalSpacer = new QSpacerItem(40, 70, QSizePolicy::Expanding, QSizePolicy::Minimum);

        verticalLayout_2->addItem(horizontalSpacer);

        horizontalLayout_14 = new QHBoxLayout();
        horizontalLayout_14->setObjectName(QStringLiteral("horizontalLayout_14"));
        label_14 = new QLabel(centralwidget);
        label_14->setObjectName(QStringLiteral("label_14"));
        label_14->setMinimumSize(QSize(0, 30));
        label_14->setMaximumSize(QSize(16777215, 30));

        horizontalLayout_14->addWidget(label_14);

        label_6 = new QLabel(centralwidget);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setMinimumSize(QSize(0, 30));
        label_6->setMaximumSize(QSize(16777215, 30));

        horizontalLayout_14->addWidget(label_6);

        label_7 = new QLabel(centralwidget);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setMinimumSize(QSize(0, 30));
        label_7->setMaximumSize(QSize(16777215, 30));

        horizontalLayout_14->addWidget(label_7);

        label_15 = new QLabel(centralwidget);
        label_15->setObjectName(QStringLiteral("label_15"));
        label_15->setMinimumSize(QSize(0, 30));
        label_15->setMaximumSize(QSize(16777215, 30));

        horizontalLayout_14->addWidget(label_15);


        verticalLayout_2->addLayout(horizontalLayout_14);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QStringLiteral("horizontalLayout_5"));
        lineEdit_7 = new QLineEdit(centralwidget);
        lineEdit_7->setObjectName(QStringLiteral("lineEdit_7"));

        horizontalLayout_5->addWidget(lineEdit_7);

        lineEdit_5 = new QLineEdit(centralwidget);
        lineEdit_5->setObjectName(QStringLiteral("lineEdit_5"));

        horizontalLayout_5->addWidget(lineEdit_5);

        lineEdit_20 = new QLineEdit(centralwidget);
        lineEdit_20->setObjectName(QStringLiteral("lineEdit_20"));

        horizontalLayout_5->addWidget(lineEdit_20);

        lineEdit_8 = new QLineEdit(centralwidget);
        lineEdit_8->setObjectName(QStringLiteral("lineEdit_8"));

        horizontalLayout_5->addWidget(lineEdit_8);


        verticalLayout_2->addLayout(horizontalLayout_5);

        pushButton_11 = new QPushButton(centralwidget);
        pushButton_11->setObjectName(QStringLiteral("pushButton_11"));

        verticalLayout_2->addWidget(pushButton_11);

        horizontalLayout_17 = new QHBoxLayout();
        horizontalLayout_17->setObjectName(QStringLiteral("horizontalLayout_17"));
        label_18 = new QLabel(centralwidget);
        label_18->setObjectName(QStringLiteral("label_18"));
        label_18->setMinimumSize(QSize(0, 30));
        label_18->setMaximumSize(QSize(16777215, 30));

        horizontalLayout_17->addWidget(label_18);

        label_8 = new QLabel(centralwidget);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setMinimumSize(QSize(0, 30));
        label_8->setMaximumSize(QSize(16777215, 30));

        horizontalLayout_17->addWidget(label_8);

        label_19 = new QLabel(centralwidget);
        label_19->setObjectName(QStringLiteral("label_19"));
        label_19->setMinimumSize(QSize(0, 30));
        label_19->setMaximumSize(QSize(16777215, 30));

        horizontalLayout_17->addWidget(label_19);

        label_20 = new QLabel(centralwidget);
        label_20->setObjectName(QStringLiteral("label_20"));
        label_20->setMinimumSize(QSize(0, 30));
        label_20->setMaximumSize(QSize(16777215, 30));

        horizontalLayout_17->addWidget(label_20);


        verticalLayout_2->addLayout(horizontalLayout_17);

        horizontalLayout_16 = new QHBoxLayout();
        horizontalLayout_16->setObjectName(QStringLiteral("horizontalLayout_16"));
        lineEdit_9 = new QLineEdit(centralwidget);
        lineEdit_9->setObjectName(QStringLiteral("lineEdit_9"));

        horizontalLayout_16->addWidget(lineEdit_9);

        lineEdit_6 = new QLineEdit(centralwidget);
        lineEdit_6->setObjectName(QStringLiteral("lineEdit_6"));

        horizontalLayout_16->addWidget(lineEdit_6);

        lineEdit_10 = new QLineEdit(centralwidget);
        lineEdit_10->setObjectName(QStringLiteral("lineEdit_10"));

        horizontalLayout_16->addWidget(lineEdit_10);

        lineEdit_21 = new QLineEdit(centralwidget);
        lineEdit_21->setObjectName(QStringLiteral("lineEdit_21"));

        horizontalLayout_16->addWidget(lineEdit_21);


        verticalLayout_2->addLayout(horizontalLayout_16);

        horizontalLayout_19 = new QHBoxLayout();
        horizontalLayout_19->setObjectName(QStringLiteral("horizontalLayout_19"));
        label_9 = new QLabel(centralwidget);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setMinimumSize(QSize(0, 30));
        label_9->setMaximumSize(QSize(16777215, 30));

        horizontalLayout_19->addWidget(label_9);

        label_21 = new QLabel(centralwidget);
        label_21->setObjectName(QStringLiteral("label_21"));
        label_21->setMinimumSize(QSize(0, 30));
        label_21->setMaximumSize(QSize(16777215, 30));

        horizontalLayout_19->addWidget(label_21);

        label_28 = new QLabel(centralwidget);
        label_28->setObjectName(QStringLiteral("label_28"));
        label_28->setMinimumSize(QSize(0, 30));
        label_28->setMaximumSize(QSize(16777215, 30));

        horizontalLayout_19->addWidget(label_28);


        verticalLayout_2->addLayout(horizontalLayout_19);

        horizontalLayout_18 = new QHBoxLayout();
        horizontalLayout_18->setObjectName(QStringLiteral("horizontalLayout_18"));
        lineEdit_11 = new QLineEdit(centralwidget);
        lineEdit_11->setObjectName(QStringLiteral("lineEdit_11"));

        horizontalLayout_18->addWidget(lineEdit_11);

        lineEdit_12 = new QLineEdit(centralwidget);
        lineEdit_12->setObjectName(QStringLiteral("lineEdit_12"));

        horizontalLayout_18->addWidget(lineEdit_12);

        lineEdit_13 = new QLineEdit(centralwidget);
        lineEdit_13->setObjectName(QStringLiteral("lineEdit_13"));

        horizontalLayout_18->addWidget(lineEdit_13);


        verticalLayout_2->addLayout(horizontalLayout_18);

        pushButton_13 = new QPushButton(centralwidget);
        pushButton_13->setObjectName(QStringLiteral("pushButton_13"));

        verticalLayout_2->addWidget(pushButton_13);

        horizontalLayout_25 = new QHBoxLayout();
        horizontalLayout_25->setObjectName(QStringLiteral("horizontalLayout_25"));
        label_22 = new QLabel(centralwidget);
        label_22->setObjectName(QStringLiteral("label_22"));
        label_22->setMinimumSize(QSize(0, 30));
        label_22->setMaximumSize(QSize(16777215, 30));

        horizontalLayout_25->addWidget(label_22);

        label_23 = new QLabel(centralwidget);
        label_23->setObjectName(QStringLiteral("label_23"));
        label_23->setMinimumSize(QSize(0, 30));
        label_23->setMaximumSize(QSize(16777215, 30));

        horizontalLayout_25->addWidget(label_23);

        label_24 = new QLabel(centralwidget);
        label_24->setObjectName(QStringLiteral("label_24"));
        label_24->setMinimumSize(QSize(0, 30));
        label_24->setMaximumSize(QSize(16777215, 30));

        horizontalLayout_25->addWidget(label_24);


        verticalLayout_2->addLayout(horizontalLayout_25);

        horizontalLayout_20 = new QHBoxLayout();
        horizontalLayout_20->setObjectName(QStringLiteral("horizontalLayout_20"));
        lineEdit_14 = new QLineEdit(centralwidget);
        lineEdit_14->setObjectName(QStringLiteral("lineEdit_14"));

        horizontalLayout_20->addWidget(lineEdit_14);

        lineEdit_15 = new QLineEdit(centralwidget);
        lineEdit_15->setObjectName(QStringLiteral("lineEdit_15"));

        horizontalLayout_20->addWidget(lineEdit_15);

        lineEdit_16 = new QLineEdit(centralwidget);
        lineEdit_16->setObjectName(QStringLiteral("lineEdit_16"));

        horizontalLayout_20->addWidget(lineEdit_16);


        verticalLayout_2->addLayout(horizontalLayout_20);

        pushButton_14 = new QPushButton(centralwidget);
        pushButton_14->setObjectName(QStringLiteral("pushButton_14"));

        verticalLayout_2->addWidget(pushButton_14);

        pushButton_25 = new QPushButton(centralwidget);
        pushButton_25->setObjectName(QStringLiteral("pushButton_25"));

        verticalLayout_2->addWidget(pushButton_25);

        horizontalLayout_48 = new QHBoxLayout();
        horizontalLayout_48->setObjectName(QStringLiteral("horizontalLayout_48"));
        pushButton_68 = new QPushButton(centralwidget);
        pushButton_68->setObjectName(QStringLiteral("pushButton_68"));
        pushButton_68->setMinimumSize(QSize(100, 0));
        pushButton_68->setAutoDefault(false);

        horizontalLayout_48->addWidget(pushButton_68);

        pushButton_69 = new QPushButton(centralwidget);
        pushButton_69->setObjectName(QStringLiteral("pushButton_69"));
        pushButton_69->setMinimumSize(QSize(100, 0));
        pushButton_69->setAutoDefault(false);

        horizontalLayout_48->addWidget(pushButton_69);

        pushButton_70 = new QPushButton(centralwidget);
        pushButton_70->setObjectName(QStringLiteral("pushButton_70"));
        pushButton_70->setMinimumSize(QSize(100, 0));
        pushButton_70->setAutoDefault(false);

        horizontalLayout_48->addWidget(pushButton_70);


        verticalLayout_2->addLayout(horizontalLayout_48);

        horizontalLayout_50 = new QHBoxLayout();
        horizontalLayout_50->setObjectName(QStringLiteral("horizontalLayout_50"));
        pushButton_75 = new QPushButton(centralwidget);
        pushButton_75->setObjectName(QStringLiteral("pushButton_75"));
        pushButton_75->setMinimumSize(QSize(100, 0));
        pushButton_75->setAutoDefault(false);

        horizontalLayout_50->addWidget(pushButton_75);


        verticalLayout_2->addLayout(horizontalLayout_50);

        horizontalLayout_35 = new QHBoxLayout();
        horizontalLayout_35->setObjectName(QStringLiteral("horizontalLayout_35"));
        pushButton_42 = new QPushButton(centralwidget);
        pushButton_42->setObjectName(QStringLiteral("pushButton_42"));
        pushButton_42->setMinimumSize(QSize(100, 0));
        pushButton_42->setAutoDefault(false);

        horizontalLayout_35->addWidget(pushButton_42);

        pushButton_43 = new QPushButton(centralwidget);
        pushButton_43->setObjectName(QStringLiteral("pushButton_43"));
        pushButton_43->setMinimumSize(QSize(100, 0));
        pushButton_43->setAutoDefault(false);

        horizontalLayout_35->addWidget(pushButton_43);

        pushButton_44 = new QPushButton(centralwidget);
        pushButton_44->setObjectName(QStringLiteral("pushButton_44"));
        pushButton_44->setMinimumSize(QSize(100, 0));
        pushButton_44->setAutoDefault(false);

        horizontalLayout_35->addWidget(pushButton_44);


        verticalLayout_2->addLayout(horizontalLayout_35);

        horizontalLayout_36 = new QHBoxLayout();
        horizontalLayout_36->setObjectName(QStringLiteral("horizontalLayout_36"));
        pushButton_45 = new QPushButton(centralwidget);
        pushButton_45->setObjectName(QStringLiteral("pushButton_45"));
        pushButton_45->setMinimumSize(QSize(100, 0));
        pushButton_45->setAutoDefault(false);

        horizontalLayout_36->addWidget(pushButton_45);

        pushButton_46 = new QPushButton(centralwidget);
        pushButton_46->setObjectName(QStringLiteral("pushButton_46"));
        pushButton_46->setMinimumSize(QSize(100, 0));
        pushButton_46->setAutoDefault(false);

        horizontalLayout_36->addWidget(pushButton_46);

        pushButton_47 = new QPushButton(centralwidget);
        pushButton_47->setObjectName(QStringLiteral("pushButton_47"));
        pushButton_47->setMinimumSize(QSize(100, 0));
        pushButton_47->setAutoDefault(false);

        horizontalLayout_36->addWidget(pushButton_47);


        verticalLayout_2->addLayout(horizontalLayout_36);


        gridLayout->addLayout(verticalLayout_2, 0, 2, 2, 1);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setSizeConstraint(QLayout::SetMaximumSize);
        verticalLayout->setContentsMargins(10, 0, -1, -1);
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, -1, 0, -1);
        pushButton_15 = new QPushButton(centralwidget);
        pushButton_15->setObjectName(QStringLiteral("pushButton_15"));
        pushButton_15->setMinimumSize(QSize(0, 50));
        pushButton_15->setMaximumSize(QSize(16777215, 50));

        horizontalLayout_2->addWidget(pushButton_15);

        pushButton_19 = new QPushButton(centralwidget);
        pushButton_19->setObjectName(QStringLiteral("pushButton_19"));
        pushButton_19->setMinimumSize(QSize(0, 50));
        pushButton_19->setMaximumSize(QSize(16777215, 50));

        horizontalLayout_2->addWidget(pushButton_19);

        pushButton_20 = new QPushButton(centralwidget);
        pushButton_20->setObjectName(QStringLiteral("pushButton_20"));
        pushButton_20->setMinimumSize(QSize(0, 50));
        pushButton_20->setMaximumSize(QSize(16777215, 50));

        horizontalLayout_2->addWidget(pushButton_20);


        verticalLayout->addLayout(horizontalLayout_2);

        label = new QLabel(centralwidget);
        label->setObjectName(QStringLiteral("label"));

        verticalLayout->addWidget(label);

        plainTextEdit = new QPlainTextEdit(centralwidget);
        plainTextEdit->setObjectName(QStringLiteral("plainTextEdit"));
        plainTextEdit->setMinimumSize(QSize(550, 300));

        verticalLayout->addWidget(plainTextEdit);

        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));

        verticalLayout->addWidget(pushButton);

        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QStringLiteral("label_2"));

        verticalLayout->addWidget(label_2);

        plainTextEdit_2 = new QPlainTextEdit(centralwidget);
        plainTextEdit_2->setObjectName(QStringLiteral("plainTextEdit_2"));
        plainTextEdit_2->setMinimumSize(QSize(550, 0));
        plainTextEdit_2->setMaximumSize(QSize(16777215, 100));

        verticalLayout->addWidget(plainTextEdit_2);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        pushButton_3 = new QPushButton(centralwidget);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));

        horizontalLayout->addWidget(pushButton_3);

        pushButton_2 = new QPushButton(centralwidget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));

        horizontalLayout->addWidget(pushButton_2);


        verticalLayout->addLayout(horizontalLayout);


        gridLayout->addLayout(verticalLayout, 1, 0, 1, 1);

        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        label_4 = new QLabel(centralwidget);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setMinimumSize(QSize(100, 50));
        label_4->setMaximumSize(QSize(100, 50));

        horizontalLayout_4->addWidget(label_4);

        comboBox = new QComboBox(centralwidget);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setMinimumSize(QSize(100, 50));
        comboBox->setMaximumSize(QSize(100, 50));

        horizontalLayout_4->addWidget(comboBox);

        label_5 = new QLabel(centralwidget);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setMinimumSize(QSize(100, 50));
        label_5->setMaximumSize(QSize(100, 50));

        horizontalLayout_4->addWidget(label_5);

        comboBox_2 = new QComboBox(centralwidget);
        comboBox_2->setObjectName(QStringLiteral("comboBox_2"));
        comboBox_2->setMinimumSize(QSize(100, 50));
        comboBox_2->setMaximumSize(QSize(100, 50));

        horizontalLayout_4->addWidget(comboBox_2);


        verticalLayout_3->addLayout(horizontalLayout_4);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        verticalLayout_3->addItem(horizontalSpacer_2);

        horizontalLayout_11 = new QHBoxLayout();
        horizontalLayout_11->setObjectName(QStringLiteral("horizontalLayout_11"));
        label_12 = new QLabel(centralwidget);
        label_12->setObjectName(QStringLiteral("label_12"));
        label_12->setMinimumSize(QSize(50, 0));
        label_12->setMaximumSize(QSize(600, 16777215));

        horizontalLayout_11->addWidget(label_12);

        lineEdit_3 = new QLineEdit(centralwidget);
        lineEdit_3->setObjectName(QStringLiteral("lineEdit_3"));
        lineEdit_3->setMinimumSize(QSize(200, 0));

        horizontalLayout_11->addWidget(lineEdit_3, 0, Qt::AlignHCenter);

        pushButton_6 = new QPushButton(centralwidget);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));
        pushButton_6->setMinimumSize(QSize(100, 0));
        pushButton_6->setAutoDefault(false);

        horizontalLayout_11->addWidget(pushButton_6);


        verticalLayout_3->addLayout(horizontalLayout_11);

        horizontalLayout_10 = new QHBoxLayout();
        horizontalLayout_10->setObjectName(QStringLiteral("horizontalLayout_10"));
        label_11 = new QLabel(centralwidget);
        label_11->setObjectName(QStringLiteral("label_11"));
        label_11->setMinimumSize(QSize(50, 0));
        label_11->setMaximumSize(QSize(150, 16777215));

        horizontalLayout_10->addWidget(label_11);

        lineEdit_2 = new QLineEdit(centralwidget);
        lineEdit_2->setObjectName(QStringLiteral("lineEdit_2"));
        lineEdit_2->setMinimumSize(QSize(200, 0));

        horizontalLayout_10->addWidget(lineEdit_2, 0, Qt::AlignHCenter);

        pushButton_5 = new QPushButton(centralwidget);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        pushButton_5->setMinimumSize(QSize(100, 0));
        pushButton_5->setAutoDefault(false);

        horizontalLayout_10->addWidget(pushButton_5);


        verticalLayout_3->addLayout(horizontalLayout_10);

        horizontalLayout_9 = new QHBoxLayout();
        horizontalLayout_9->setObjectName(QStringLiteral("horizontalLayout_9"));
        label_10 = new QLabel(centralwidget);
        label_10->setObjectName(QStringLiteral("label_10"));
        label_10->setMinimumSize(QSize(50, 0));
        label_10->setMaximumSize(QSize(150, 16777215));

        horizontalLayout_9->addWidget(label_10);

        lineEdit = new QLineEdit(centralwidget);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setMinimumSize(QSize(200, 0));

        horizontalLayout_9->addWidget(lineEdit, 0, Qt::AlignHCenter);

        pushButton_4 = new QPushButton(centralwidget);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setMinimumSize(QSize(100, 0));
        pushButton_4->setAutoDefault(false);

        horizontalLayout_9->addWidget(pushButton_4);


        verticalLayout_3->addLayout(horizontalLayout_9);

        horizontalLayout_21 = new QHBoxLayout();
        horizontalLayout_21->setObjectName(QStringLiteral("horizontalLayout_21"));
        pushButton_16 = new QPushButton(centralwidget);
        pushButton_16->setObjectName(QStringLiteral("pushButton_16"));
        pushButton_16->setMinimumSize(QSize(100, 0));
        pushButton_16->setAutoDefault(false);

        horizontalLayout_21->addWidget(pushButton_16);

        pushButton_17 = new QPushButton(centralwidget);
        pushButton_17->setObjectName(QStringLiteral("pushButton_17"));
        pushButton_17->setMinimumSize(QSize(100, 0));
        pushButton_17->setAutoDefault(false);

        horizontalLayout_21->addWidget(pushButton_17);

        pushButton_18 = new QPushButton(centralwidget);
        pushButton_18->setObjectName(QStringLiteral("pushButton_18"));
        pushButton_18->setMinimumSize(QSize(100, 0));
        pushButton_18->setAutoDefault(false);

        horizontalLayout_21->addWidget(pushButton_18);


        verticalLayout_3->addLayout(horizontalLayout_21);

        horizontalLayout_12 = new QHBoxLayout();
        horizontalLayout_12->setObjectName(QStringLiteral("horizontalLayout_12"));
        label_13 = new QLabel(centralwidget);
        label_13->setObjectName(QStringLiteral("label_13"));
        label_13->setMinimumSize(QSize(50, 0));

        horizontalLayout_12->addWidget(label_13);

        lineEdit_4 = new QLineEdit(centralwidget);
        lineEdit_4->setObjectName(QStringLiteral("lineEdit_4"));
        lineEdit_4->setMinimumSize(QSize(200, 0));

        horizontalLayout_12->addWidget(lineEdit_4);

        pushButton_7 = new QPushButton(centralwidget);
        pushButton_7->setObjectName(QStringLiteral("pushButton_7"));
        pushButton_7->setMinimumSize(QSize(100, 0));
        pushButton_7->setAutoDefault(false);

        horizontalLayout_12->addWidget(pushButton_7);


        verticalLayout_3->addLayout(horizontalLayout_12);

        horizontalLayout_22 = new QHBoxLayout();
        horizontalLayout_22->setObjectName(QStringLiteral("horizontalLayout_22"));
        label_25 = new QLabel(centralwidget);
        label_25->setObjectName(QStringLiteral("label_25"));
        label_25->setMinimumSize(QSize(50, 0));

        horizontalLayout_22->addWidget(label_25);

        lineEdit_17 = new QLineEdit(centralwidget);
        lineEdit_17->setObjectName(QStringLiteral("lineEdit_17"));
        lineEdit_17->setMinimumSize(QSize(200, 0));

        horizontalLayout_22->addWidget(lineEdit_17);

        pushButton_22 = new QPushButton(centralwidget);
        pushButton_22->setObjectName(QStringLiteral("pushButton_22"));
        pushButton_22->setMinimumSize(QSize(100, 0));
        pushButton_22->setAutoDefault(false);

        horizontalLayout_22->addWidget(pushButton_22);


        verticalLayout_3->addLayout(horizontalLayout_22);

        horizontalLayout_23 = new QHBoxLayout();
        horizontalLayout_23->setObjectName(QStringLiteral("horizontalLayout_23"));
        label_26 = new QLabel(centralwidget);
        label_26->setObjectName(QStringLiteral("label_26"));
        label_26->setMinimumSize(QSize(50, 0));

        horizontalLayout_23->addWidget(label_26);

        lineEdit_18 = new QLineEdit(centralwidget);
        lineEdit_18->setObjectName(QStringLiteral("lineEdit_18"));
        lineEdit_18->setMinimumSize(QSize(200, 0));

        horizontalLayout_23->addWidget(lineEdit_18);

        pushButton_23 = new QPushButton(centralwidget);
        pushButton_23->setObjectName(QStringLiteral("pushButton_23"));
        pushButton_23->setMinimumSize(QSize(100, 0));
        pushButton_23->setAutoDefault(false);

        horizontalLayout_23->addWidget(pushButton_23);


        verticalLayout_3->addLayout(horizontalLayout_23);

        horizontalLayout_24 = new QHBoxLayout();
        horizontalLayout_24->setObjectName(QStringLiteral("horizontalLayout_24"));
        label_27 = new QLabel(centralwidget);
        label_27->setObjectName(QStringLiteral("label_27"));
        label_27->setMinimumSize(QSize(50, 0));

        horizontalLayout_24->addWidget(label_27);

        lineEdit_19 = new QLineEdit(centralwidget);
        lineEdit_19->setObjectName(QStringLiteral("lineEdit_19"));
        lineEdit_19->setMinimumSize(QSize(200, 0));

        horizontalLayout_24->addWidget(lineEdit_19);

        pushButton_24 = new QPushButton(centralwidget);
        pushButton_24->setObjectName(QStringLiteral("pushButton_24"));
        pushButton_24->setMinimumSize(QSize(100, 0));
        pushButton_24->setAutoDefault(false);

        horizontalLayout_24->addWidget(pushButton_24);


        verticalLayout_3->addLayout(horizontalLayout_24);

        horizontalLayout_13 = new QHBoxLayout();
        horizontalLayout_13->setObjectName(QStringLiteral("horizontalLayout_13"));
        pushButton_10 = new QPushButton(centralwidget);
        pushButton_10->setObjectName(QStringLiteral("pushButton_10"));
        pushButton_10->setMinimumSize(QSize(100, 0));
        pushButton_10->setAutoDefault(false);

        horizontalLayout_13->addWidget(pushButton_10);

        pushButton_9 = new QPushButton(centralwidget);
        pushButton_9->setObjectName(QStringLiteral("pushButton_9"));
        pushButton_9->setMinimumSize(QSize(100, 0));
        pushButton_9->setAutoDefault(false);

        horizontalLayout_13->addWidget(pushButton_9);

        pushButton_8 = new QPushButton(centralwidget);
        pushButton_8->setObjectName(QStringLiteral("pushButton_8"));
        pushButton_8->setMinimumSize(QSize(100, 0));
        pushButton_8->setAutoDefault(false);

        horizontalLayout_13->addWidget(pushButton_8);


        verticalLayout_3->addLayout(horizontalLayout_13);

        pushButton_21 = new QPushButton(centralwidget);
        pushButton_21->setObjectName(QStringLiteral("pushButton_21"));

        verticalLayout_3->addWidget(pushButton_21);

        horizontalLayout_52 = new QHBoxLayout();
        horizontalLayout_52->setObjectName(QStringLiteral("horizontalLayout_52"));
        pushButton_80 = new QPushButton(centralwidget);
        pushButton_80->setObjectName(QStringLiteral("pushButton_80"));
        pushButton_80->setMinimumSize(QSize(100, 0));
        pushButton_80->setAutoDefault(false);

        horizontalLayout_52->addWidget(pushButton_80);

        pushButton_81 = new QPushButton(centralwidget);
        pushButton_81->setObjectName(QStringLiteral("pushButton_81"));
        pushButton_81->setMinimumSize(QSize(100, 0));
        pushButton_81->setAutoDefault(false);

        horizontalLayout_52->addWidget(pushButton_81);

        pushButton_82 = new QPushButton(centralwidget);
        pushButton_82->setObjectName(QStringLiteral("pushButton_82"));
        pushButton_82->setMinimumSize(QSize(100, 0));
        pushButton_82->setAutoDefault(false);

        horizontalLayout_52->addWidget(pushButton_82);


        verticalLayout_3->addLayout(horizontalLayout_52);

        horizontalLayout_34 = new QHBoxLayout();
        horizontalLayout_34->setObjectName(QStringLiteral("horizontalLayout_34"));
        pushButton_39 = new QPushButton(centralwidget);
        pushButton_39->setObjectName(QStringLiteral("pushButton_39"));
        pushButton_39->setMinimumSize(QSize(100, 0));
        pushButton_39->setAutoDefault(false);

        horizontalLayout_34->addWidget(pushButton_39);

        pushButton_40 = new QPushButton(centralwidget);
        pushButton_40->setObjectName(QStringLiteral("pushButton_40"));
        pushButton_40->setMinimumSize(QSize(100, 0));
        pushButton_40->setAutoDefault(false);

        horizontalLayout_34->addWidget(pushButton_40);

        pushButton_41 = new QPushButton(centralwidget);
        pushButton_41->setObjectName(QStringLiteral("pushButton_41"));
        pushButton_41->setMinimumSize(QSize(100, 0));
        pushButton_41->setAutoDefault(false);

        horizontalLayout_34->addWidget(pushButton_41);


        verticalLayout_3->addLayout(horizontalLayout_34);

        horizontalLayout_37 = new QHBoxLayout();
        horizontalLayout_37->setObjectName(QStringLiteral("horizontalLayout_37"));
        pushButton_48 = new QPushButton(centralwidget);
        pushButton_48->setObjectName(QStringLiteral("pushButton_48"));
        pushButton_48->setMinimumSize(QSize(100, 0));
        pushButton_48->setAutoDefault(false);

        horizontalLayout_37->addWidget(pushButton_48);

        pushButton_49 = new QPushButton(centralwidget);
        pushButton_49->setObjectName(QStringLiteral("pushButton_49"));
        pushButton_49->setMinimumSize(QSize(100, 0));
        pushButton_49->setAutoDefault(false);

        horizontalLayout_37->addWidget(pushButton_49);

        pushButton_50 = new QPushButton(centralwidget);
        pushButton_50->setObjectName(QStringLiteral("pushButton_50"));
        pushButton_50->setMinimumSize(QSize(100, 0));
        pushButton_50->setAutoDefault(false);

        horizontalLayout_37->addWidget(pushButton_50);


        verticalLayout_3->addLayout(horizontalLayout_37);

        horizontalLayout_38 = new QHBoxLayout();
        horizontalLayout_38->setObjectName(QStringLiteral("horizontalLayout_38"));
        pushButton_51 = new QPushButton(centralwidget);
        pushButton_51->setObjectName(QStringLiteral("pushButton_51"));
        pushButton_51->setMinimumSize(QSize(100, 0));
        pushButton_51->setAutoDefault(false);

        horizontalLayout_38->addWidget(pushButton_51);

        pushButton_52 = new QPushButton(centralwidget);
        pushButton_52->setObjectName(QStringLiteral("pushButton_52"));
        pushButton_52->setMinimumSize(QSize(100, 0));
        pushButton_52->setAutoDefault(false);

        horizontalLayout_38->addWidget(pushButton_52);

        pushButton_53 = new QPushButton(centralwidget);
        pushButton_53->setObjectName(QStringLiteral("pushButton_53"));
        pushButton_53->setMinimumSize(QSize(100, 0));
        pushButton_53->setAutoDefault(false);

        horizontalLayout_38->addWidget(pushButton_53);


        verticalLayout_3->addLayout(horizontalLayout_38);


        gridLayout->addLayout(verticalLayout_3, 1, 1, 1, 1);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 1342, 21));
        menu = new QMenu(menubar);
        menu->setObjectName(QStringLiteral("menu"));
        menu_2 = new QMenu(menubar);
        menu_2->setObjectName(QStringLiteral("menu_2"));
        menu_3 = new QMenu(menubar);
        menu_3->setObjectName(QStringLiteral("menu_3"));
        menu_4 = new QMenu(menubar);
        menu_4->setObjectName(QStringLiteral("menu_4"));
        menu_5 = new QMenu(menubar);
        menu_5->setObjectName(QStringLiteral("menu_5"));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        MainWindow->setStatusBar(statusbar);

        menubar->addAction(menu->menuAction());
        menubar->addAction(menu_2->menuAction());
        menubar->addAction(menu_3->menuAction());
        menubar->addAction(menu_4->menuAction());
        menubar->addAction(menu_5->menuAction());

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", Q_NULLPTR));
        state->setText(QApplication::translate("MainWindow", "\344\270\262\345\217\243\346\234\252\345\274\200\345\220\257", Q_NULLPTR));
        label_14->setText(QApplication::translate("MainWindow", "KP", Q_NULLPTR));
        label_6->setText(QApplication::translate("MainWindow", "KI1", Q_NULLPTR));
        label_7->setText(QApplication::translate("MainWindow", "KI2", Q_NULLPTR));
        label_15->setText(QApplication::translate("MainWindow", "KD", Q_NULLPTR));
        lineEdit_7->setText(QApplication::translate("MainWindow", "1.5", Q_NULLPTR));
        lineEdit_5->setText(QApplication::translate("MainWindow", "1.5", Q_NULLPTR));
        lineEdit_20->setText(QApplication::translate("MainWindow", "1.5", Q_NULLPTR));
        lineEdit_8->setText(QApplication::translate("MainWindow", "0.5", Q_NULLPTR));
        pushButton_11->setText(QApplication::translate("MainWindow", "\344\277\256\346\224\271\347\224\265\346\234\272PID", Q_NULLPTR));
        label_18->setText(QApplication::translate("MainWindow", "Line_Time", Q_NULLPTR));
        label_8->setText(QApplication::translate("MainWindow", "Font_Time", Q_NULLPTR));
        label_19->setText(QApplication::translate("MainWindow", "Back_Time", Q_NULLPTR));
        label_20->setText(QApplication::translate("MainWindow", "Stop_Time", Q_NULLPTR));
        lineEdit_9->setText(QApplication::translate("MainWindow", "60", Q_NULLPTR));
        lineEdit_6->setText(QApplication::translate("MainWindow", "240", Q_NULLPTR));
        lineEdit_10->setText(QApplication::translate("MainWindow", "170", Q_NULLPTR));
        lineEdit_21->setText(QApplication::translate("MainWindow", "600", Q_NULLPTR));
        label_9->setText(QApplication::translate("MainWindow", "OUT_Line", Q_NULLPTR));
        label_21->setText(QApplication::translate("MainWindow", "IN_Line", Q_NULLPTR));
        label_28->setText(QApplication::translate("MainWindow", "Slow_Down", Q_NULLPTR));
        lineEdit_11->setText(QApplication::translate("MainWindow", "160", Q_NULLPTR));
        lineEdit_12->setText(QApplication::translate("MainWindow", "100", Q_NULLPTR));
        lineEdit_13->setText(QApplication::translate("MainWindow", "200", Q_NULLPTR));
        pushButton_13->setText(QApplication::translate("MainWindow", "\344\277\256\346\224\271\345\212\250\344\275\234\345\217\202\346\225\260", Q_NULLPTR));
        label_22->setText(QApplication::translate("MainWindow", "state", Q_NULLPTR));
        label_23->setText(QApplication::translate("MainWindow", "acc", Q_NULLPTR));
        label_24->setText(QApplication::translate("MainWindow", "angle", Q_NULLPTR));
        lineEdit_14->setText(QApplication::translate("MainWindow", "1", Q_NULLPTR));
        lineEdit_15->setText(QApplication::translate("MainWindow", "150", Q_NULLPTR));
        lineEdit_16->setText(QApplication::translate("MainWindow", "180", Q_NULLPTR));
        pushButton_14->setText(QApplication::translate("MainWindow", "\345\274\200\345\247\213\346\265\213\350\257\225", Q_NULLPTR));
        pushButton_25->setText(QApplication::translate("MainWindow", "\345\201\234\346\255\242\346\265\213\350\257\225", Q_NULLPTR));
        pushButton_68->setText(QApplication::translate("MainWindow", "\344\276\247\346\226\271\344\275\215", Q_NULLPTR));
        pushButton_69->setText(QApplication::translate("MainWindow", "\345\205\245\345\272\223", Q_NULLPTR));
        pushButton_70->setText(QApplication::translate("MainWindow", "\345\207\272\345\272\223", Q_NULLPTR));
        pushButton_75->setText(QApplication::translate("MainWindow", "\345\244\215\344\275\215\345\201\234\350\275\246", Q_NULLPTR));
        pushButton_42->setText(QApplication::translate("MainWindow", "\345\276\205\345\256\232", Q_NULLPTR));
        pushButton_43->setText(QApplication::translate("MainWindow", "\345\276\205\345\256\232", Q_NULLPTR));
        pushButton_44->setText(QApplication::translate("MainWindow", "\345\276\205\345\256\232", Q_NULLPTR));
        pushButton_45->setText(QApplication::translate("MainWindow", "\345\276\205\345\256\232", Q_NULLPTR));
        pushButton_46->setText(QApplication::translate("MainWindow", "\345\276\205\345\256\232", Q_NULLPTR));
        pushButton_47->setText(QApplication::translate("MainWindow", "\345\276\205\345\256\232", Q_NULLPTR));
        pushButton_15->setText(QApplication::translate("MainWindow", "\346\211\223\345\274\200\344\270\262\345\217\243", Q_NULLPTR));
        pushButton_19->setText(QApplication::translate("MainWindow", "\345\205\263\351\227\255\344\270\262\345\217\243", Q_NULLPTR));
        pushButton_20->setText(QApplication::translate("MainWindow", "\345\210\267\346\226\260\344\270\262\345\217\243", Q_NULLPTR));
        label->setText(QApplication::translate("MainWindow", "\346\216\245\346\224\266\345\214\272", Q_NULLPTR));
        pushButton->setText(QApplication::translate("MainWindow", "\346\270\205\347\251\272\346\216\245\346\224\266\345\214\272", Q_NULLPTR));
        label_2->setText(QApplication::translate("MainWindow", "\345\217\221\351\200\201\345\214\272", Q_NULLPTR));
        pushButton_3->setText(QApplication::translate("MainWindow", "\345\217\221\351\200\201", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("MainWindow", "\346\270\205\347\251\272\345\217\221\351\200\201\345\214\272", Q_NULLPTR));
        label_4->setText(QApplication::translate("MainWindow", "\344\270\262\345\217\243\345\217\267\357\274\232", Q_NULLPTR));
        label_5->setText(QApplication::translate("MainWindow", "\346\263\242\347\211\271\347\216\207\357\274\232", Q_NULLPTR));
        comboBox_2->clear();
        comboBox_2->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "115200", Q_NULLPTR)
         << QApplication::translate("MainWindow", "9600", Q_NULLPTR)
        );
        label_12->setText(QApplication::translate("MainWindow", "Sp1", Q_NULLPTR));
        lineEdit_3->setText(QApplication::translate("MainWindow", "300", Q_NULLPTR));
        pushButton_6->setText(QApplication::translate("MainWindow", "\345\217\221\351\200\201", Q_NULLPTR));
        label_11->setText(QApplication::translate("MainWindow", "Sp2", Q_NULLPTR));
        lineEdit_2->setText(QApplication::translate("MainWindow", "-300", Q_NULLPTR));
        pushButton_5->setText(QApplication::translate("MainWindow", "\345\217\221\351\200\201", Q_NULLPTR));
        label_10->setText(QApplication::translate("MainWindow", "SP3", Q_NULLPTR));
        lineEdit->setText(QApplication::translate("MainWindow", "500", Q_NULLPTR));
        pushButton_4->setText(QApplication::translate("MainWindow", "\345\217\221\351\200\201", Q_NULLPTR));
        pushButton_16->setText(QApplication::translate("MainWindow", "-300", Q_NULLPTR));
        pushButton_17->setText(QApplication::translate("MainWindow", "0", Q_NULLPTR));
        pushButton_18->setText(QApplication::translate("MainWindow", "300", Q_NULLPTR));
        label_13->setText(QApplication::translate("MainWindow", "PWM", Q_NULLPTR));
        lineEdit_4->setText(QApplication::translate("MainWindow", "200", Q_NULLPTR));
        pushButton_7->setText(QApplication::translate("MainWindow", "\345\217\221\351\200\201", Q_NULLPTR));
        label_25->setText(QApplication::translate("MainWindow", "Ag1", Q_NULLPTR));
        lineEdit_17->setText(QApplication::translate("MainWindow", "0", Q_NULLPTR));
        pushButton_22->setText(QApplication::translate("MainWindow", "\345\217\221\351\200\201", Q_NULLPTR));
        label_26->setText(QApplication::translate("MainWindow", "Ag2", Q_NULLPTR));
        lineEdit_18->setText(QApplication::translate("MainWindow", "0", Q_NULLPTR));
        pushButton_23->setText(QApplication::translate("MainWindow", "\345\217\221\351\200\201", Q_NULLPTR));
        label_27->setText(QApplication::translate("MainWindow", "error", Q_NULLPTR));
        lineEdit_19->setText(QApplication::translate("MainWindow", "0", Q_NULLPTR));
        pushButton_24->setText(QApplication::translate("MainWindow", "\345\217\221\351\200\201", Q_NULLPTR));
        pushButton_10->setText(QApplication::translate("MainWindow", "\346\234\200\345\267\246", Q_NULLPTR));
        pushButton_9->setText(QApplication::translate("MainWindow", "\345\261\205\344\270\255", Q_NULLPTR));
        pushButton_8->setText(QApplication::translate("MainWindow", "\346\234\200\345\217\263", Q_NULLPTR));
        pushButton_21->setText(QApplication::translate("MainWindow", "\350\234\202\351\270\243\345\231\250\346\265\213\350\257\225", Q_NULLPTR));
        pushButton_80->setText(QApplication::translate("MainWindow", "\345\276\205\345\256\232", Q_NULLPTR));
        pushButton_81->setText(QApplication::translate("MainWindow", "\345\276\205\345\256\232", Q_NULLPTR));
        pushButton_82->setText(QApplication::translate("MainWindow", "\345\276\205\345\256\232", Q_NULLPTR));
        pushButton_39->setText(QApplication::translate("MainWindow", "\345\276\205\345\256\232", Q_NULLPTR));
        pushButton_40->setText(QApplication::translate("MainWindow", "\345\276\205\345\256\232", Q_NULLPTR));
        pushButton_41->setText(QApplication::translate("MainWindow", "\345\276\205\345\256\232", Q_NULLPTR));
        pushButton_48->setText(QApplication::translate("MainWindow", "\345\276\205\345\256\232", Q_NULLPTR));
        pushButton_49->setText(QApplication::translate("MainWindow", "\345\276\205\345\256\232", Q_NULLPTR));
        pushButton_50->setText(QApplication::translate("MainWindow", "\345\276\205\345\256\232", Q_NULLPTR));
        pushButton_51->setText(QApplication::translate("MainWindow", "\345\276\205\345\256\232", Q_NULLPTR));
        pushButton_52->setText(QApplication::translate("MainWindow", "\345\276\205\345\256\232", Q_NULLPTR));
        pushButton_53->setText(QApplication::translate("MainWindow", "\345\276\205\345\256\232", Q_NULLPTR));
        menu->setTitle(QApplication::translate("MainWindow", "\346\226\207\344\273\266", Q_NULLPTR));
        menu_2->setTitle(QApplication::translate("MainWindow", "\350\247\206\345\233\276", Q_NULLPTR));
        menu_3->setTitle(QApplication::translate("MainWindow", "\347\274\226\350\276\221", Q_NULLPTR));
        menu_4->setTitle(QApplication::translate("MainWindow", "\345\267\245\345\205\267", Q_NULLPTR));
        menu_5->setTitle(QApplication::translate("MainWindow", "\345\205\263\344\272\216", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
