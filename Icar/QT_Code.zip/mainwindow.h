#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QSerialPort>
#include <QSerialPortInfo>
#include <QDebug>

typedef union {
    int16_t int16bit;
    uint8_t b[2];
} int16Bytes;

typedef union {
    float f;
    uint8_t b[4];
} FloatBytes;

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);

    void buzzerRing(void);

    void setMotorSpeed(int16_t speed);

    void setServoPWM(uint16_t servoPwm);

    void setMotorPID(float kp,float ki1, float ki2 ,float kd);

    void setServoPID(float kp,float ki, float kd);

    void setServoBendPI(float kp,float ki);

    void setServoLinePI(float kp,float ki);

    void parking(uint8_t commond);

    ~MainWindow();

private slots:
    void messlot();

    void on_pushButton_15_clicked();

    void on_pushButton_19_clicked();

    void on_pushButton_20_clicked();

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_16_clicked();

    void on_pushButton_17_clicked();

    void on_pushButton_18_clicked();

    void on_pushButton_6_clicked();

    void on_pushButton_5_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_10_clicked();

    void on_pushButton_9_clicked();

    void on_pushButton_8_clicked();

    void on_pushButton_7_clicked();

    void on_pushButton_11_clicked();

    void on_pushButton_14_clicked();

    void on_pushButton_21_clicked();

    void on_pushButton_25_clicked();

    void on_pushButton_68_clicked();

    void on_pushButton_69_clicked();

    void on_pushButton_70_clicked();

    void on_pushButton_75_clicked();

    void on_pushButton_24_clicked();

    void on_pushButton_13_clicked();

private:
    Ui::MainWindow *ui;
    QSerialPort m_serial;
};
#endif // MAINWINDOW_H
