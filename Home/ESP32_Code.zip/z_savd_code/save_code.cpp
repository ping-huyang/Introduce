/*************************************************************************************
* @note    : freeRtos测试代码 
* @note    : none 
* @note    : none 
* @note    : none
* @time     : 2023/06/24 15:25:05
*************************************************************************************/
#include <Arduino.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>

void task1(void *pvParameters);
void task2(void *pvParameters);

void setup()
{
    // 初始化串口，波特率115200
    Serial.begin(115200); // 初始化串口通信，波特率为115200
    // 创建任务1和任务2
    xTaskCreate(task1, "Task 1", 10240, NULL, 1, NULL);
    xTaskCreate(task2, "Task 2", 10240, NULL, 2, NULL);
    // 启动FreeRTOS调度器
    vTaskStartScheduler();
}

void loop()
{
    if (Serial.available()){    
        char c = Serial.read(); 
        Serial.write(c);       
    }
    Serial.printf("main loop is doing\r\n");
    sleep(1);
}

void task1(void *pvParameters)
{
    while (1){
        Serial.printf("task1 loop is doing\r\n");
        vTaskDelay(pdMS_TO_TICKS(500));
    }
}

void task2(void *pvParameters)
{
    while (1){
        Serial.printf("task2 loop is doing\r\n");
        vTaskDelay(pdMS_TO_TICKS(500));
    }
}


/*************************************************************************************
* @note    : 点灯测试 
* @note    : none 
* @note    : none 
* @note    : none
* @time     : 2023/06/24 15:42:25
*************************************************************************************/
#define LED_Pin 2

void setup(void)
{
    pinMode(LED_Pin, OUTPUT);
    digitalWrite(LED_Pin,HIGH);
}

void loop(void)
{
    digitalWrite(LED_Pin,HIGH);
    sleep(1);
    digitalWrite(LED_Pin,LOW);
    sleep(1);
}


/*************************************************************************************
* @note    : 触摸按钮测试 
* @note    : none 
* @note    : none 
* @note    : none
* @time     : 2023/06/24 15:52:33
*************************************************************************************/
#define LED_Pin 2

uint16_t touchValue;

void setup(void)
{
    Serial.begin(115200);
    pinMode(LED_Pin,OUTPUT);
}

void loop(void)
{
    touchValue = touchRead(T0);
    if(touchValue <= 30){
        digitalWrite(LED_Pin,HIGH);
    }else{
        digitalWrite(LED_Pin,LOW);
    }
}


/*************************************************************************************
* @note    : 匿名助手波形显示 
* @note    : none 
* @note    : none 
* @note    : none
* @time     : 2023/06/24 19:20:52
*************************************************************************************/
wave_display wave(&Serial);

void setup(void)
{
    Serial.begin(115200);
}

uint16_t f[2];

void loop(void)
{
    f[0] += 1;
    if(f[0] >= 200) f[0] = 0;
    f[1] += 2;
    if(f[1] >= 400) f[1] = 0;
    wave.drawUint16(f,2);
    delay(20);
}


/*************************************************************************************
* @note    : u8x8显示测试 
* @note    : none 
* @note    : none 
* @note    : none
* @time     : 2023/06/24 20:51:54
*************************************************************************************/
#include <Wire.h>
#include <U8x8lib.h>

U8X8_SSD1306_128X64_NONAME_SW_I2C u8x8(SCL, SDA, U8X8_PIN_NONE);

// 定义显示区域的长和宽
const uint8_t display_width = 16;
const uint8_t display_height = 8;

// 定义当前光标所在位置
uint8_t cursor_x = 0;
uint8_t cursor_y = 0;

void setup() {
  u8x8.begin();
  u8x8.setFont(u8x8_font_chroma48medium8_r);
  u8x8.setFlipMode(1); // 开启缓存模式
  u8x8.clearDisplay();
}

void loop() {
  u8x8.setCursor(cursor_x, cursor_y);
  u8x8.print("Hello, world!");
  delay(1000);
  u8x8.clearLine(cursor_y);
  cursor_y++;
  if (cursor_y >= display_height) {
    cursor_y = 0;
  }
}


/*************************************************************************************
* @note    : u8g2Demo 
* @note    : none 
* @note    : none 
* @note    : none
* @time     : 2023/06/24 21:51:31
*************************************************************************************/
#include <Wire.h>
#include <U8g2lib.h>

U8G2_SSD1306_128X64_NONAME_F_HW_I2C u8g2(U8G2_R0, U8X8_PIN_NONE);

int counter = 0;

void setup() {
  Wire.begin();
  u8g2.begin();
  u8g2.firstPage();
  do {
    u8g2.setFont(u8g2_font_ncenB10_tr);
    u8g2.drawStr(0, 20, "Hello, world!");
    u8g2.drawStr(0, 40, "Hello, world!");
    u8g2.drawStr(0, 63, "Hello, world!");
  } while (u8g2.nextPage());
}

void loop() {
  delay(1000);
}


/*************************************************************************************
* @note    : none 
* @note    : none 
* @note    : none 
* @note    : none
* @time     : 2023/07/01 14:10:06
*************************************************************************************/

#include "../include/commond.h"
#include <Wire.h>
#include <U8x8lib.h>

#define U8LOG_WIDTH 16
#define U8LOG_HEIGHT 8
uint8_t u8log_buffer[U8LOG_WIDTH*U8LOG_HEIGHT];
U8X8LOG u8x8log;

U8X8_SSD1306_128X64_NONAME_SW_I2C u8x8(SCL, SDA, U8X8_PIN_NONE);

void setup(void)
{
  u8x8.begin();
  u8x8.setFont(u8x8_font_chroma48medium8_r);
  u8x8log.begin(u8x8, U8LOG_WIDTH, U8LOG_HEIGHT, u8log_buffer);
  u8x8log.setRedrawMode(0);		// 0: Update screen with newline, 1: Update screen for every char  
}

unsigned long t = 0;

void loop(void) {
  u8x8log.print("hello:");
  u8x8log.print(t);
  u8x8log.print("\n");
  t++;
  delay(1000);
}


/*************************************************************************************
* @note    : 串口判断字符串 
* @note    : none 
* @note    : none 
* @note    : none
* @time     : 2023/06/25 09:59:48
*************************************************************************************/
// 定义一个 String 类型的变量来存放输入字符串
String inputString;
// 字符串是否接收完整的标志位
bool stringComplete = false;
inputString.reserve(50);

// while (Serial.available())
// {
//     char inChar = (char)Serial.read();
//     if (inChar == '\n')
//     {
//         stringComplete = true;
//     }
//     else
//     {
//         inputString += inChar;
//     }
// }

// if (stringComplete)
// {
//     Serial.print("Received: ");
//     Serial.println(inputString);
//     if (inputString.equalsIgnoreCase("cls") == 0)
//     {
//         printf("come CLS\n");
//         OLED.Clear();
//     }
//     else if (inputString.equalsIgnoreCase("home") == 0)
//     {
//         OLED.ShowHomePage();
//         printf("come HOME\n");
//     }
//     else
//     {
//         // 屏幕模拟终端显示
//         printf("come INFO\n");
//         OLED.INFO(inputString.c_str());
//     }
//     inputString = "";
//     stringComplete = false;
// }


/*************************************************************************************
* @note    : 三个串口测试 
* @note    : none 
* @note    : none 
* @note    : none
* @time     : 2023/06/27 18:14:24
*************************************************************************************/
void setup()
{
    Serial.begin(115200);
    Serial1.begin(115200, SERIAL_8N1, 26, 25); // 将UART1的RXD映射到GPIO8，将TXD映射到GPIO9
    Serial2.begin(115200);
    OLED.Ready();
    Key_Init();
    delay(2000);
}

void loop()
{
    OLED.OLED_Serial_Terminal(&Serial);
    Key_Loop(10);
    Serial.write("Serial");
    Serial1.write("Serial1");
    Serial2.write("Serial2");
    delay(1000);
}


/*************************************************************************************
* @note    : 无源蜂鸣器播放音乐 
* @note    : none 
* @note    : none 
* @note    : none
* @time     : 2023/06/29 17:22:12
*************************************************************************************/

class Buzzer {
public:
  Buzzer(uint8_t sig_pin) : pwm_pin(sig_pin) {
    ledcSetup(pwm_channel, frequency, resolution);
    ledcAttachPin(pwm_pin, pwm_channel);
  }

  void play(const uint16_t *melodies, size_t size, unsigned long wait, uint16_t duty) {
    for (size_t i = 0; i < size; ++i) {
      uint16_t note = melodies[i];
      Serial.print("note:");
      Serial.println(note);
      if (note) {
        ledcWriteTone(pwm_channel, note);
      }
      ledcWrite(pwm_channel, duty);
      delay(wait);
    }
    ledcWrite(pwm_channel, 0);
  }

private:
  const uint8_t pwm_channel = 0;
  const uint8_t resolution = 10;
  uint8_t pwm_pin;
  uint16_t frequency = 2000;
};

// 音符与对应的的频率
uint16_t B0_1 = 31,C1 = 33,CS1 = 35,D1 = 37,DS1 = 39,E1 = 41,F1 = 44,FS1 = 46,G1 = 49,GS1 = 52,
A1 = 55,AS1 = 58,B1_1 = 62,C2 = 65,CS2 = 69,D2 = 73,DS2 = 78,E2 = 82,F2 = 87,FS2 = 93,G2 = 98,
GS2 = 104,A2 = 110,AS2 = 117,B2 = 123,C3 = 131,CS3 = 139,D3 = 147,DS3 = 156,E3 = 165,F3 = 175,
FS3 = 185,G3 = 196,GS3 = 208,A3_1 = 220,AS3 = 233,B3 = 247,C4 = 262,CS4 = 277,D4 = 294,DS4 = 311,
E4 = 330,F4 = 349,FS4 = 370,G4 = 392,GS4 = 415,A4_1 = 440,AS4_1 = 466,B4 = 494,C5 = 523,CS5 = 554,
D5 = 587,DS5 = 622,E5 = 659,F5 = 698,FS5 = 740,G5 = 784,GS5 = 831,A5_1 = 880,AS5 = 932,B5 = 988,
C6 = 1047,CS6 = 1109,D6 = 1175,DS6 = 1245,E6 = 1319,F6 = 1397,FS6 = 1480,G6 = 1568,GS6 = 1661,
A6_1 = 1760,AS6 = 1865,B6 = 1976,C7 = 2093,CS7 = 2217,D7 = 2349,DS7 = 2489,E7 = 2637,F7 = 2794,
FS7 = 2960,G7 = 3136,GS7 = 3322,A7_1 = 3520,AS7 = 3729,B7 = 3951,C8 = 4186,CS8 = 4435,D8 = 4699,
DS8 = 4978;

// 第一首，超级马里奥乐谱
const uint16_t mario[] = {
    E7, E7, 0, E7, 0, C7, E7, 0,
    G7, 0, 0, 0, G6, 0, 0, 0,
    C7, 0, 0, G6, 0, 0, E6, 0,
    0, A6_1, 0, B6, 0, AS6, A6_1, 0,
    G6, E7, 0, G7, A7_1, 0, F7, G7,
    0, E7, 0, C7, D7, B6, 0, 0,
    C7, 0, 0, G6, 0, 0, E6, 0,
    0, A6_1, 0, B6, 0, AS6, A6_1, 0,
    G6, E7, 0, G7, A7_1, 0, F7, G7,
    0, E7, 0, C7, D7, B6, 0, 0,
};

// 第二首，jingle bells
const uint16_t jingle[] = {
    E7, E7, E7, 0,
    E7, E7, E7, 0,
    E7, G7, C7, D7, E7, 0,
    F7, F7, F7, F7, F7, E7, E7, E7, E7, D7, D7, E7, D7, 0, G7, 0,
    E7, E7, E7, 0,
    E7, E7, E7, 0,
    E7, G7, C7, D7, E7, 0,
    F7, F7, F7, F7, F7, E7, E7, E7, G7, G7, F7, D7, C7, 0
};

// 初始化蜂鸣器对象
Buzzer buzzer(4);

void setup() {
  Serial.begin(115200);
}

void loop() {
  Serial.println("播放 超级马里奥");
  buzzer.play(mario, sizeof(mario) / sizeof(mario[0]), 150, 512);
  delay(1000);
  Serial.println("播放 jingle bells.");
  buzzer.play(jingle, sizeof(jingle) / sizeof(jingle[0]), 250, 512);
  delay(1000);
}


/*************************************************************************************
* @note    : none 
* @note    : none 
* @note    : none 
* @note    : none
* @time     : 2023/07/01 14:08:59
*************************************************************************************/
void setup()
{
    Serial.begin(115200);
    Meun_Init();
    KEY_Init();
}

void loop()
{
    KEY_Number = KEY_Scan(0);
    if(KEY_Number != 0){
        keyAction[KEY_Number - 1]();
    }

    meun_loop();
}