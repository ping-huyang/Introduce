#include "../include/oled.hpp"

MY_OLED OLED(U8G2_R0, U8X8_PIN_NONE);

void MY_OLED::Ready(void)
{
    Wire.begin();
    begin();
    enableUTF8Print();
}

void MY_OLED::Clear(void)
{
    clearBuffer();
    sendBuffer();
    for (int i = 0; i < 4; i++)
    {
        strbuf[i] = "";
        strp[i] = "";
    }
}

void MY_OLED::INFO(const char *format, ...)
{
    static uint8_t line_num = 3;
    line_num = (++line_num) % 4;
    char buf[30];
    va_list args;
    va_start(args, format);
    vsnprintf(buf, sizeof(buf), format, args);
    va_end(args);
    strbuf[line_num] = buf;
    strp[0] = strp[1];
    strp[1] = strp[2];
    strp[2] = strp[3];
    strp[3] = strbuf[line_num];
    firstPage();
    do
    {
        for (uint8_t i = 0; i < 4; i++)
        {
            if (!strp[i].isEmpty())
            {
                drawStr(0, 15 + i * 16, strp[i].c_str());
            }
        }
    } while (nextPage());
}


void MY_OLED::OLED_Serial_Terminal(HardwareSerial *serial)
{
    if (serial->available())
    {                                      
        String Serial_RecStr = serial->readStringUntil('\n');
        serial->println(Serial_RecStr);
        if (Serial_RecStr == "cls"){                            
            Clear();
        }else if(Serial_RecStr == "home"){
            ShowHomePage();
        }else{
            INFO(Serial_RecStr.c_str());
        }
    }
}


/*************************************************************************************
* @note    : none 
* @note    : none 
* @note    : none 
* @note    : none
* @time     : 2023/06/30 15:06:21
*************************************************************************************/
void MY_OLED::ShowHomePage(void)
{
    firstPage();
    do
    {
        setFontMode(1);
        setFontDirection(0);
        setFont(u8g2_font_inb16_mf);
        drawStr(0, 22, "U");
        setFontDirection(1);
        setFont(u8g2_font_inb19_mn);
        drawStr(14, 8, "8");
        setFontDirection(0);
        setFont(u8g2_font_inb16_mf);
        drawStr(36, 22, "g");
        drawStr(48, 22, "\xb2");
        drawHLine(2, 25, 34);
        drawHLine(3, 26, 34);
        drawVLine(32, 22, 12);
        drawVLine(33, 23, 12);
        setFont(u8g2_font_ncenB10_tr);
    } while (nextPage());
}

void MY_OLED::ShowChinese(void)
{
    setFont(u8g2_font_unifont_t_chinese2);
    setFontDirection(0);
    firstPage();
    do
    {
        setCursor(0, 15);
        print("Hello World!");
        setCursor(0, 40);
        print("你好世界");
    } while (nextPage());
}
