#ifndef __WAVE_DISPLAY_
#define __WAVE_DISPLAY_
#include "HardwareSerial.h"

class wave_display
{
private:
    HardwareSerial* serial;
public:
    wave_display(HardwareSerial* serial);
    ~wave_display();

public:
    void test(void);
    void drawFloat(float* buf, uint8_t size);
    void drawUint16(uint16_t* buf, uint8_t size);
};

typedef union {
  float f;
  uint8_t b[4];
} floatBytes;

typedef union {
  uint16_t uint16;
  int16_t int16;
  uint8_t b[2];
} int16Bytes;

#endif
