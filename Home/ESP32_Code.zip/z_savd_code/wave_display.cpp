#include "../include/wave_display.hpp"

/*************************************************************************************
* @note    : 匿名助手波形显示封装方便使用 
* @note    : none 
* @note    : none 
* @note    : none
* @time     : 2023/06/24 17:35:25
*************************************************************************************/

wave_display::wave_display(HardwareSerial* serial)
{
    this->serial = serial;
    printf("wave_display was done\r\n");
}

wave_display::~wave_display()
{
    printf("~wave_display was done\r\n");
}

void wave_display::test()
{
    this->serial->printf("So Cool\r\n");
}

int16Bytes data_size;
void wave_display::drawFloat(float* buf, uint8_t size)
{
    uint8_t sumcheck = 0;
    uint8_t addcheck = 0;
    data_size.uint16 = size*4;
    floatBytes f[size];
    uint8_t commond[size*4 + 8] = {0xAB,0xFF,0xFE,0xF2};
    commond[4] = data_size.b[0];
    commond[5] = data_size.b[1];
    for(uint8_t i = 0 ; i < size ; i++)
    {
        f[i].f = buf[i];
        commond[6+i*4] = f[i].b[0];
        commond[7+i*4] = f[i].b[1];
        commond[8+i*4] = f[i].b[2];
        commond[9+i*4] = f[i].b[3]; 
    }
    for(uint16_t i=0; i < (size*4 + 6); i++)
    {
        sumcheck += commond[i]; 
        addcheck += sumcheck; 
    }
    commond[data_size.uint16+6] = sumcheck;
    commond[data_size.uint16+7] = addcheck;
    this->serial->write(commond,(size*4 + 8));
}

void wave_display::drawUint16(uint16_t* buf, uint8_t size)
{
    uint8_t sumcheck = 0;
    uint8_t addcheck = 0;
    data_size.uint16 = size*2;
    int16Bytes f[size];
    uint8_t commond[size*2 + 8] = {0xAB,0xF1,0xFE,0xF1};
    commond[4] = data_size.b[0];
    commond[5] = data_size.b[1];
    for(uint8_t i = 0 ; i < size ; i++)
    {
        f[i].int16 = buf[i];
        commond[6+i*2] = f[i].b[0];
        commond[7+i*2] = f[i].b[1];
    }
    for(uint16_t i=0; i < (size*2 + 6); i++)
    {
        sumcheck += commond[i]; 
        addcheck += sumcheck; 
    }
    commond[data_size.uint16+6] = sumcheck;
    commond[data_size.uint16+7] = addcheck;
    this->serial->write(commond,(size*2 + 8));
}
