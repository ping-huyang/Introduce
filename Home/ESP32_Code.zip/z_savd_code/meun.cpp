#include "../include/meun.hpp"
#include "Wire.h"

U8G2_SSD1306_128X64_NONAME_F_HW_I2C u8g2(U8G2_R0, U8X8_PIN_NONE);

uint8_t meun_event;

struct menu_state current_state = {ICON_BGAP, ICON_BGAP, 0};
struct menu_state destination_state = {ICON_BGAP, ICON_BGAP, 0};

struct menu_entry_type menu_entry_list[] =
    {
        {u8g2_font_open_iconic_embedded_4x_t, 65, "Clock Setup"},
        {u8g2_font_open_iconic_embedded_4x_t, 66, "Gear Game"},
        {u8g2_font_open_iconic_embedded_4x_t, 67, "Flash Light"},
        {u8g2_font_open_iconic_embedded_4x_t, 68, "Home"},
        {u8g2_font_open_iconic_embedded_4x_t, 72, "Configuration"},
        {NULL, 0, NULL}};

void Meun_Init(void)
{
    Wire.begin();
    u8g2.begin();
    u8g2.setFont(u8g2_font_6x12_tr);
}

void draw(struct menu_state *state)
{
    int16_t x;
    uint8_t i;
    x = state->menu_start;
    i = 0;
    while (menu_entry_list[i].icon > 0)
    {
        if (x >= -ICON_WIDTH && x < u8g2.getDisplayWidth())
        {
            u8g2.setFont(menu_entry_list[i].font);
            u8g2.drawGlyph(x, ICON_Y, menu_entry_list[i].icon);
        }
        i++;
        x += ICON_WIDTH + ICON_GAP;
    }
    u8g2.drawFrame(state->frame_position - 1, ICON_Y - ICON_HEIGHT - 1, ICON_WIDTH + 2, ICON_WIDTH + 2);
    u8g2.drawFrame(state->frame_position - 2, ICON_Y - ICON_HEIGHT - 2, ICON_WIDTH + 4, ICON_WIDTH + 4);
    u8g2.drawFrame(state->frame_position - 3, ICON_Y - ICON_HEIGHT - 3, ICON_WIDTH + 6, ICON_WIDTH + 6);
}

void to_right(struct menu_state *state)
{
    if (menu_entry_list[state->position + 1].font != NULL)
    {
        if ((int16_t)state->frame_position + 2 * (int16_t)ICON_WIDTH + (int16_t)ICON_BGAP < (int16_t)u8g2.getDisplayWidth())
        {
            state->position++;
            state->frame_position += ICON_WIDTH + (int16_t)ICON_GAP;
        }
        else
        {
            state->position++;
            state->frame_position = (int16_t)u8g2.getDisplayWidth() - (int16_t)ICON_WIDTH - (int16_t)ICON_BGAP;
            state->menu_start = state->frame_position - state->position * ((int16_t)ICON_WIDTH + (int16_t)ICON_GAP);
        }
    }
}

void to_left(struct menu_state *state)
{
    if (state->position > 0)
    {
        if ((int16_t)state->frame_position >= (int16_t)ICON_BGAP + (int16_t)ICON_WIDTH + (int16_t)ICON_GAP)
        {
            state->position--;
            state->frame_position -= ICON_WIDTH + (int16_t)ICON_GAP;
        }
        else
        {
            state->position--;
            state->frame_position = ICON_BGAP;
            state->menu_start = state->frame_position - state->position * ((int16_t)ICON_WIDTH + (int16_t)ICON_GAP);
        }
    }
}

uint8_t towards_int16(int16_t *current, int16_t dest)
{
    if (*current < dest)
    {
        (*current)++;
        return 1;
    }
    else if (*current > dest)
    {
        (*current)--;
        return 1;
    }
    return 0;
}

uint8_t towards(struct menu_state *current, struct menu_state *destination)
{
    uint8_t r = 0;
    r |= towards_int16(&(current->frame_position), destination->frame_position);
    r |= towards_int16(&(current->frame_position), destination->frame_position);
    r |= towards_int16(&(current->menu_start), destination->menu_start);
    r |= towards_int16(&(current->menu_start), destination->menu_start);
    return r;
}

void meun_loop(void)
{
    do
    {
        u8g2.clearBuffer();
        draw(&current_state);
        u8g2.setFont(u8g2_font_helvB10_tr);
        u8g2.setCursor((u8g2.getDisplayWidth() - u8g2.getStrWidth(menu_entry_list[destination_state.position].name)) / 2, u8g2.getDisplayHeight() - 5);
        u8g2.print(menu_entry_list[destination_state.position].name);
        u8g2.sendBuffer();
        delay(10);
        if (meun_event == 1)
        {
            to_left(&destination_state);
            meun_event = 0;
        }
        if (meun_event == 2)
        {
            to_right(&destination_state);
            meun_event = 0;
        }
        if (meun_event == 3)
        {
            u8g2.setFont(u8g2_font_helvB10_tr);
            u8g2.userInterfaceMessage("Selection:", menu_entry_list[destination_state.position].name, "", " Ok ");
            meun_event = 0;
        }
        if(meun_event == 4)
        {
            // 设置目标状态为您想返回的位置，例如位置0
            destination_state.position = 0;
            destination_state.frame_position = ICON_BGAP;
            destination_state.menu_start = ICON_BGAP;
            meun_event = 0;
        }
    } while (towards(&current_state, &destination_state));
}
