#ifndef __TEST_H__
#define __TEST_H__
#include "common.h"
#include <U8g2lib.h>

/*
  Icon configuration
  Width and height must match the icon font size
  GAP: Space between the icons
  BGAP: Gap between the display border and the cursor.
*/
#define ICON_WIDTH 32
#define ICON_HEIGHT 32
#define ICON_GAP 4
#define ICON_BGAP 16
#define ICON_Y 32 + ICON_GAP

struct menu_entry_type
{
    const uint8_t *font;
    uint16_t icon;
    const char *name;
};

struct menu_state
{
    int16_t menu_start;     /* in pixel */
    int16_t frame_position; /* in pixel */
    uint8_t position;       /* position, array index */
};

void Meun_Init(void);
void meun_loop(void);

extern uint8_t meun_event;
extern U8G2_SSD1306_128X64_NONAME_F_HW_I2C u8g2;

#endif
