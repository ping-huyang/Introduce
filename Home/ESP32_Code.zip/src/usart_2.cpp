#include "usart_2.hpp"

uint8_t hexData[] = {0xF3, 0xAB, 0x01, 0x00, 0x00};

void sendCommond(uint8_t commond)
{
    hexData[3] = commond;
    uint8_t sum = 0;
    for(uint8_t i = 0 ; i < 4 ; i++){
        sum += hexData[i];
    }
    hexData[4] = sum;
    Serial2.write(hexData,5);
}

