#include "gpio.hpp"

MY_LED LED(LED_Pin);
MY_BEEP BEEP(BEEP_Pin);

/*************************************************************************************
* @note    : LED控制函数 
* @note    : none 
* @note    : none 
* @note    : none
* @time     : 2023/06/29 20:09:55
*************************************************************************************/
void MY_LED::ON(void)
{
    digitalWrite(ledPin,HIGH);
}

void MY_LED::OFF(void)
{
    digitalWrite(ledPin,LOW);
}

void MY_LED::Toggle(void)
{
    digitalWrite(ledPin,1-digitalRead(ledPin));
}


/*************************************************************************************
* @note    : 无源蜂鸣器控制函数 
* @note    : none 
* @note    : none 
* @note    : none
* @time     : 2023/06/29 20:10:11
*************************************************************************************/

// 第一首，超级马里奥乐谱
const uint16_t mario[] = {
    1319, 1319, 0, 1319, 0, 1047, 1319, 0,
    1568, 0, 0, 0, 784, 0, 0, 0,
    1047, 0, 0, 784, 0, 0, 659, 0,
    0, 880, 0, 988, 0, 932, 880, 0,
    784, 1319, 0, 1568, 1760, 0, 1397, 1568,
    0, 1319, 0, 1047, 1175, 988, 0, 0,
    1047, 0, 0, 784, 0, 0, 659, 0,
    0, 880, 0, 988, 0, 932, 880, 0,
    784, 1319, 0, 1568, 1760, 0, 1397, 1568,
    0, 1319, 0, 1047, 1175, 988, 0, 0,
};

// 第二首，叮叮当，叮叮当
const uint16_t jingle[] = {
    2637, 2637, 2637, 0,
    2637, 2637, 2637, 0,
    2637, 3136, 2093, 2349, 2637, 0,
    2794, 2794, 2794, 2794, 2794, 2637, 2637, 2637, 2637, 2349, 2349, 2637, 2349, 0, 3136, 0,
    2637, 2637, 2637, 0,
    2637, 2637, 2637, 0,
    2637, 3136, 2093, 2349, 2637, 0,
    2794, 2794, 2794, 2794, 2794, 2637, 2637, 2637, 3136, 3136, 2794, 2349, 2093, 0
};

// 第三首，自定义音乐
const uint16_t simple_music[] = {
    262, 262, 392, 392, 440, 440, 392, 0,
    349, 349, 330, 330, 294, 294, 262, 0,
    392, 392, 349, 349, 330, 330, 294, 0,
    392, 392, 349, 349, 330, 330, 294, 0,
    262, 262, 392, 392, 440, 440, 392, 0,
    349, 349, 330, 330, 294, 294, 262, 0,
    392, 392, 349, 349, 330, 330, 294, 0,
    392, 392, 349, 349, 330, 330, 294, 0,
};

/**
* @brief    : 无源蜂鸣器播放音乐 
* @param    : none 
* @return   : none 
* @author   : HuQingpei
* @note     : 2023/06/30 14:58:51
**/
void MY_BEEP::play(const uint16_t *melodies, size_t size, unsigned long wait, uint16_t duty = 150) {
    for (size_t i = 0; i < size; ++i) {
      uint16_t note = melodies[i];
      if (note) {
        ledcWriteTone(pwm_channel, note);
      }
      ledcWrite(pwm_channel, duty);
      delay(wait);
    }
    ledcWrite(pwm_channel, 0);
  }

void MY_BEEP::Play_mario(void){
    play(mario, sizeof(mario) / sizeof(mario[0]), 150);
}

void MY_BEEP::Play_jingle(void){
    play(jingle, sizeof(jingle) / sizeof(jingle[0]), 250);
}

void MY_BEEP::Play_music(void){
    play(simple_music, sizeof(simple_music) / sizeof(simple_music[0]), 250);
}


/**
* @brief    : 播放设置时长的音调，delay延时控制 
* @param    : none 
* @return   : none 
* @author   : HuQingpei
* @note     : 2023/06/30 14:59:28
**/
void MY_BEEP::play(const uint16_t note, unsigned long wait, uint16_t duty = 150)
{
    ledcWriteTone(pwm_channel, note);
    ledcWrite(pwm_channel, duty);
    delay(wait);
    ledcWrite(pwm_channel, 0);
}

/**
* @brief    : 单纯地设置一个音调 
* @param    : none 
* @return   : none 
* @author   : HuQingpei
* @note     : 2023/06/30 15:00:18
**/
void MY_BEEP::play(const uint16_t note, uint16_t duty = 150)
{
    ledcWriteTone(pwm_channel, note);
    ledcWrite(pwm_channel, duty);
}

