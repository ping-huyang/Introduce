#include "key.hpp"
#include "usart_2.hpp"

/*************************************************************************************
* @note    : 使用我最熟悉的按键扫描来实现 
* @note    : none 
* @note    : none 
* @note    : none
* @time     : 2023/06/30 23:18:27
*************************************************************************************/
void KEY_Init(void)
{
    pinMode(KEY1_Pin, INPUT_PULLUP);
    pinMode(KEY2_Pin, INPUT_PULLUP);
    pinMode(KEY3_Pin, INPUT_PULLUP);
    pinMode(KEY4_Pin, INPUT_PULLUP);
}

uint8_t KEY_Scan(uint8_t mode)
{ 
	static uint8_t key_up=1;
	if(mode)key_up=1;
	if(key_up&&(KEY1==0||KEY2==0||KEY3==0||KEY4==0))
	{
		delay(20);
		key_up=0;
		if(KEY1==0)return 1;
		else if(KEY2==0)return 2;
		else if(KEY3==0)return 3;
		else if(KEY4==0)return 4;
	}else if(KEY1==1&&KEY2==1&&KEY3==1&&KEY4==1)key_up=1; 	    
 	return 0;
}

void key1_Click(void){
    sendCommond(0);
    Serial.printf("key1 was clicked !!!\r\n");
}

void key2_Click(void){
    sendCommond(1);
    Serial.printf("key2 was clicked !!!\r\n");
}

void key3_Click(void){
    sendCommond(2);
    Serial.printf("key3 was clicked !!!\r\n");
}

void key4_Click(void){
    sendCommond(3);
    Serial.printf("key4 was clicked !!!\r\n");
}

#define KEY_ACTION_FUNCTION_NUMS 4
uint8_t KEY_Number;
KeyFuncPrt keyAction[KEY_ACTION_FUNCTION_NUMS] = {
    key1_Click,
    key2_Click,
    key3_Click,
    key4_Click
};


/*************************************************************************************
* @note    : Meun菜单使用的按键扫描方法 
* @note    : none 
* @note    : none 
* @note    : none
* @time     : 2023/07/01 14:44:14
*************************************************************************************/
KEY key[4] = {false};
KEY_MSG key_msg = {0};

bool get_key_val(uint8_t ch)
{
    switch (ch)
    {
    case 0:
        return digitalRead(KEY1_Pin);
        break;
    case 1:
        return digitalRead(KEY2_Pin);
        break;
    case 2:
        return digitalRead(KEY3_Pin);
        break;
    case 3:
        return digitalRead(KEY4_Pin);
        break;
    default:
        return 0;
        break;
    }
}

void Key_Meun_Init()
{
    KEY_Init();
    for (uint8_t i = 0; i < (sizeof(key) / sizeof(KEY)); ++i)
    {
        key[i].val = key[i].last_val = get_key_val(i);
    }
}

void Key_Meun_Scan()
{
    for (uint8_t i = 0; i < (sizeof(key) / sizeof(KEY)); ++i)
    {
        key[i].val = get_key_val(i);       // 获取键值
        if (key[i].last_val != key[i].val) // 发生改变
        {
            key[i].last_val = key[i].val; // 更新状态
            if (key[i].val == LOW)
            {
                key_msg.id = i;
                key_msg.pressed = true;
            }
        }
    }
}

/*************************************************************************************
* @note    : 使用OneButton库来实现按键检测功能 
* @note    : none 
* @note    : none 
* @note    : none
* @time     : 2023/06/30 23:14:35
*************************************************************************************/
#include "OneButton.h"
// save the millis when a press has started.
unsigned long pressStartTime;
// Setup a new OneButton on pin KEY1_Pin
// The 2. parameter activeLOW is true, because external wiring sets the button_1 to LOW when pressed.
OneButton button_1(KEY1_Pin, true);
OneButton button_2(KEY2_Pin, true);
OneButton button_3(KEY3_Pin, true);
OneButton button_4(KEY4_Pin, true);

// return the touch_key Value
uint16_t Touch_Key_Value(void)
{
    return touchRead(Touch_KEY);
}

// this function will be called when the button_1 was pressed 1 time in a short timeframe.
void singleClick_1()
{
    Serial.printf("b-1 clicked !!");
}

// this function will be called when the button_2 was pressed 1 time in a short timeframe.
void singleClick_2()
{
    Serial.printf("b-2 clicked !!");
}

// this function will be called when the button_3 was pressed 1 time in a short timeframe.
void singleClick_3()
{
    Serial.printf("b-3 clicked !!");
}

// this function will be called when the button_4 was pressed 1 time in a short timeframe.
void singleClick_4()
{
    Serial.printf("b-4 clicked !!");
}

// this function will be called when the button_1 was pressed 2 times in a short timeframe.
void doubleClick_1()
{
    Serial.println("doubleClick() detected.");
}

// this function will be called when the button_1 was pressed multiple times in a short timeframe.
void multiClick_1()
{
    Serial.print("multiClick(");
    Serial.print(button_1.getNumberClicks());
    Serial.println(") detected.");
}

// this function will be called when the button_1 was held down for 1 second or more.
void pressStart_1()
{
    Serial.println("pressStart()");
    pressStartTime = millis() - 1000; // as set in setPressTicks()
}

// this function will be called when the button_1 was released after a long hold.
void pressStop_1()
{
    Serial.print("pressStop(");
    Serial.print(millis() - pressStartTime);
    Serial.println(") detected.");
}

// key_Init function
void Key_OneButton_Init(void)
{
    // singleClicked 
    button_1.attachClick(singleClick_1);
    button_2.attachClick(singleClick_2);
    button_3.attachClick(singleClick_3);
    button_4.attachClick(singleClick_4);

    // // doubleClicked
    // button_1.attachDoubleClick(doubleClick_1);
    // button_2.attachDoubleClick(doubleClick_2);
    // button_3.attachDoubleClick(doubleClick_3);
    // button_4.attachDoubleClick(doubleClick_4);

    // // MultiClicked
    // button_1.attachMultiClick(multiClick_1);
    // button_2.attachMultiClick(multiClick_2);
    // button_3.attachMultiClick(multiClick_3);
    // button_4.attachMultiClick(multiClick_4);

    // // that is the time when LongPressStart is called
    // button_1.setPressTicks(1000);
    // button_1.attachLongPressStart(pressStart_1);
    // button_1.attachLongPressStop(pressStop_1);
    // button_2.setPressTicks(1000);
    // button_2.attachLongPressStart(pressStart_2);
    // button_2.attachLongPressStop(pressStop_2);
    // button_3.setPressTicks(1000);
    // button_3.attachLongPressStart(pressStart_3);
    // button_3.attachLongPressStop(pressStop_3);
    // button_4.setPressTicks(1000);
    // button_4.attachLongPressStart(pressStart_4);
    // button_4.attachLongPressStop(pressStop_4);
}

// KEY_Scan for test which key was passed
void Key_OneButton_Scan(uint16_t delay_Time_ms)
{
    button_1.tick();
    button_2.tick();
    button_3.tick();
    button_4.tick();
    delay(delay_Time_ms);
}



