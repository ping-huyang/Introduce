#include "../include/common.h"

void setup()
{
    Serial.begin(115200);
    Serial2.begin(115200);
    Key_Meun_Init();
    Meun_Init();
}

void loop()
{
    Key_Meun_Scan();
    ui_proc();
}

// #include <WiFi.h>
// #include <PubSubClient.h>

// const char *ssid = "IceLand_Phone_wifi";   // WiFi名称
// const char *password = "helloworld";       // WiFi密码
// const char *mqtt_server = "118.24.37.234"; // MQTT代理服务器IP地址
// const char *mqtt_username = "Iceland";     // MQTT用户名
// const char *mqtt_password = "Iceland.666"; // MQTT密码
// const char *mqtt_topic = "ESP32";          // MQTT主题

// WiFiClient wifiClient;
// PubSubClient mqttClient(wifiClient);

// void mqttConnect()
// {
//     while (!mqttClient.connected())
//     {
//         Serial.println("正在连接MQTT代理服务器...");
//         if (mqttClient.connect("ESP32客户端", mqtt_username, mqtt_password))
//         {
//             Serial.println("MQTT连接成功！");
//             mqttClient.subscribe(mqtt_topic);
//         }
//         else
//         {
//             Serial.print("MQTT连接失败，状态码：");
//             Serial.println(mqttClient.state());
//             delay(5000);
//         }
//     }
// }

// void mqttCallback(char *topic, byte *payload, unsigned int length)
// {
//     Serial.print("收到MQTT消息：");
//     Serial.write(payload, length);
//     Serial.println();
// }

// void setup()
// {
//     Serial.begin(115200);
//     WiFi.begin(ssid, password);
//     while (WiFi.status() != WL_CONNECTED)
//     {
//         delay(1000);
//         Serial.println("正在连接WiFi...");
//     }
//     mqttClient.setServer(mqtt_server, 1883);
//     mqttClient.setCallback(mqttCallback);
// }

// void loop()
// {
//     if (!mqttClient.connected())
//     {
//         mqttConnect();
//     }
//     mqttClient.loop();

//     // 发布消息到MQTT主题
//     char payload[] = "Hello MQTT!";
//     mqttClient.publish(mqtt_topic, payload);
//     delay(1000);
// }
