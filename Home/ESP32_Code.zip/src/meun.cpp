#include "../include/meun.hpp"
#include "../include/images.h"
#include "Wire.h"

U8G2_SSD1306_128X64_NONAME_F_HW_I2C u8g2(U8G2_R0, U8X8_PIN_NONE);

SELECT_LIST list[]{
    {"MainUI"},
    {"-MotorControl"},
    {"-LEDControl"},
    {"-BuzzerMusic"},
    {"-{About}"},
    {"-{Page-One}"},
    {"-{Page-Two}"},
    {"-{Page-Thr}"},
    {"-{Page-For}"},
};

SELECT_LIST icon[]{
    {"LED_Toggle"},
    {"LED_OFF"},
    {"LED_ON"},
    {"Go_Back"},
};

SELECT_LIST buzzer_icon[]{
    {"Play_mario"},
    {"Play_jingle"},
    {"Play_music"},
    {"Go_Back"},
};

SELECT_LIST motor_icon[]{
    {"Motor_Toggle_FONT"},
    {"Motor_Toggle_BACK"},
    {"Servo_Toggle"},
    {"Go_Back"},
};

uint8_t icon_width[] = {35, 37, 36, 36};
uint8_t disappear_step = 1;
uint8_t *buf_ptr;// 指向buf首地址的指针
uint16_t buf_len;// 选择界面变量
uint8_t x;
int16_t y, y_trg;                 // 目标和当前
uint8_t line_y, line_y_trg;       // 线的位置
uint8_t box_width, box_width_trg; // 框的宽度
int16_t box_y, box_y_trg;         // 框的当前值和目标值
int8_t ui_select;                 // 当前选中那一栏
uint8_t list_num = sizeof(list) / sizeof(SELECT_LIST); // 选择界面数量
uint8_t single_line_length = 63 / list_num;
uint8_t total_line_length = single_line_length * list_num + 1;
uint8_t icon_num = sizeof(icon) / sizeof(SELECT_LIST);
int16_t icon_x, icon_x_trg;// icon界面变量
int16_t app_y, app_y_trg;
int8_t icon_select;
uint8_t ui_index, ui_state;

/*************************************************************************************
* @note    : 界面初始化函数 
* @note    : none 
* @note    : none 
* @note    : none
* @time     : 2023/07/01 15:43:36
*************************************************************************************/
void Meun_Init(void)
{
    u8g2.setBusClock(800000);
    Wire.begin();
    u8g2.begin();
    u8g2.setFont(u8g2_font_wqy12_t_chinese1);
    u8g2.enableUTF8Print();
    buf_ptr = u8g2.getBufferPtr();
    buf_len = 8 * u8g2.getBufferTileHeight() * u8g2.getBufferTileWidth();
    x = 4;
    y = y_trg = 0;
    line_y = line_y_trg = 1;
    ui_select  = icon_select = 0;
    icon_x = icon_x_trg = 0;
    app_y = app_y_trg = 0;
    box_width = box_width_trg = u8g2.getStrWidth(list[ui_select].select) + x * 2;           
    ui_index = M_LOGO;
    ui_state = S_NONE;
}

/*************************************************************************************
* @note    : 移动或功能函数 
* @note    : none 
* @note    : none 
* @note    : none
* @time     : 2023/07/01 15:14:26
*************************************************************************************/
// 移动函数
bool move(int16_t *a, int16_t *a_trg)
{
    if (*a < *a_trg)
    {
        *a += SPEED;
        if (*a > *a_trg)
            *a = *a_trg; 
    }
    else if (*a > *a_trg)
    {
        *a -= SPEED;
        if (*a < *a_trg)
            *a = *a_trg; 
    }
    else
    {
        return true; 
    }
    return false; 
}

// 移动函数
bool move_icon(int16_t *a, int16_t *a_trg)
{
    if (*a < *a_trg)
    {
        *a += ICON_SPEED;
        if (*a > *a_trg)
            *a = *a_trg; 
    }
    else if (*a > *a_trg)
    {
        *a -= ICON_SPEED;
        if (*a < *a_trg)
            *a = *a_trg; 
    }
    else
    {
        return true; 
    }
    return false;
}

// 宽度移动函数
bool move_width(uint8_t *a, uint8_t *a_trg, uint8_t select, uint8_t id)
{
    if (*a < *a_trg)
    {
        uint8_t step = 16 / SPEED;
        uint8_t len;
        if (ui_index == M_SELECT)
        {
            len = abs(u8g2.getStrWidth(list[select].select) - u8g2.getStrWidth(list[id == 0 ? select + 1 : select - 1].select));
        }
        uint8_t width_speed = ((len % step) == 0 ? (len / step) : (len / step + 1)); // 计算步长
        *a += width_speed;
        if (*a > *a_trg)
            *a = *a_trg; 
    }
    else if (*a > *a_trg)
    {
        uint8_t step = 16 / SPEED; 
        uint8_t len;
        if (ui_index == M_SELECT)
        {
            len = abs(u8g2.getStrWidth(list[select].select) - u8g2.getStrWidth(list[id == 0 ? select + 1 : select - 1].select));
        }
        uint8_t width_speed = ((len % step) == 0 ? (len / step) : (len / step + 1)); // 计算步长
        *a -= width_speed;
        if (*a < *a_trg)
            *a = *a_trg;
    }
    else
    {
        return true; 
    }
    return false; 
}

// 进度条移动函数
bool move_bar(uint8_t *a, uint8_t *a_trg)
{
    if (*a < *a_trg)
    {
        uint8_t step = 16 / SPEED;                                                                                                // 判断步数
        uint8_t width_speed = ((single_line_length % step) == 0 ? (single_line_length / step) : (single_line_length / step + 1)); // 计算步长
        *a += width_speed;
        if (*a > *a_trg)
            *a = *a_trg; 
    }
    else if (*a > *a_trg)
    {
        uint8_t step = 16 / SPEED;                                                                                                // 判断步数
        uint8_t width_speed = ((single_line_length % step) == 0 ? (single_line_length / step) : (single_line_length / step + 1)); // 计算步长
        *a -= width_speed;
        if (*a < *a_trg)
            *a = *a_trg;
    }
    else
    {
        return true; 
    }
    return false; 
}

// 消失函数
void disappear()
{
    switch (disappear_step)
    {
    case 1:
        for (uint16_t i = 0; i < buf_len; ++i)
        {
            if (i % 2 == 0)
                buf_ptr[i] = buf_ptr[i] & 0x55;
        }
        break;
    case 2:
        for (uint16_t i = 0; i < buf_len; ++i)
        {
            if (i % 2 != 0)
                buf_ptr[i] = buf_ptr[i] & 0xAA;
        }
        break;
    case 3:
        for (uint16_t i = 0; i < buf_len; ++i)
        {
            if (i % 2 == 0)
                buf_ptr[i] = buf_ptr[i] & 0x00;
        }
        break;
    case 4:
        for (uint16_t i = 0; i < buf_len; ++i)
        {
            if (i % 2 != 0)
                buf_ptr[i] = buf_ptr[i] & 0x00;
        }
        break;
    default:
        ui_state = S_NONE;
        disappear_step = 0;
        break;
    }
    disappear_step++;
}


/*************************************************************************************
* @note    : ui 界面设计 
* @note    : none 
* @note    : none 
* @note    : none
* @time     : 2023/07/01 15:14:48
*************************************************************************************/
void logo_ui_show() // 显示logo
{
    u8g2.drawXBMP(0, 0, 128, 64, LOGO);
}

void select_ui_show() // 选择界面
{
    move_bar(&line_y, &line_y_trg);
    move(&y, &y_trg);
    move(&box_y, &box_y_trg);
    move_width(&box_width, &box_width_trg, ui_select, key_msg.id);
    u8g2.drawVLine(126, 0, total_line_length);
    u8g2.drawPixel(125, 0);
    u8g2.drawPixel(127, 0);
    for (uint8_t i = 0; i < list_num; ++i)
    {
        u8g2.drawStr(x, 16 * i + y + 12, list[i].select); 
        u8g2.drawPixel(125, single_line_length * (i + 1));
        u8g2.drawPixel(127, single_line_length * (i + 1));
    }
    u8g2.drawVLine(125, line_y, single_line_length - 1);
    u8g2.drawVLine(127, line_y, single_line_length - 1);
    u8g2.setDrawColor(2);
    u8g2.drawRBox(0, box_y, box_width, 16, 1);
    u8g2.setDrawColor(1);
}

void icon_ui_show(void) // 显示icon
{
    move_icon(&icon_x, &icon_x_trg);
    move(&app_y, &app_y_trg);

    for (uint8_t i = 0; i < icon_num; ++i)
    {
        u8g2.drawXBMP(46 + icon_x + i * ICON_SPACE, 6, 36, icon_width[i], icon_pic_1[i]);
        u8g2.setClipWindow(0, 48, 128, 64);
        u8g2.drawStr((128 - u8g2.getStrWidth(icon[i].select)) / 2, 62 - app_y + i * 16, icon[i].select);
        u8g2.setMaxClipWindow();
    }
}

void about_ui_show(void) // about界面
{
    u8g2.drawStr(2, 12, "MCU : ESP32");
    u8g2.drawStr(2, 28, "FLASH : 4MB");
    u8g2.drawStr(2, 44, "SRAM : 520KB");
    u8g2.drawStr(2, 60, "RTC SRAM : 16KB");
}

void terminal_ui_show(void)
{
    move_icon(&icon_x, &icon_x_trg);
    move(&app_y, &app_y_trg);
    for (uint8_t i = 0; i < icon_num; ++i)
    {
        u8g2.drawXBMP(46 + icon_x + i * ICON_SPACE, 6, 36, icon_width[i], icon_pic[i]);
        u8g2.setClipWindow(0, 48, 128, 64);
        u8g2.drawStr((128 - u8g2.getStrWidth(motor_icon[i].select)) / 2, 62 - app_y + i * 16, motor_icon[i].select);
        u8g2.setMaxClipWindow();
    }
}

void buzzer_music_ui_show(void)
{
    move_icon(&icon_x, &icon_x_trg);
    move(&app_y, &app_y_trg);
    for (uint8_t i = 0; i < icon_num; ++i)
    {
        u8g2.drawXBMP(46 + icon_x + i * ICON_SPACE, 6, 36, icon_width[i], icon_pic[i]);
        u8g2.setClipWindow(0, 48, 128, 64);
        u8g2.drawStr((128 - u8g2.getStrWidth(buzzer_icon[i].select)) / 2, 62 - app_y + i * 16, buzzer_icon[i].select);
        u8g2.setMaxClipWindow();
    }
}

/*************************************************************************************
* @note    : 界面处理函数 
* @note    : none 
* @note    : none 
* @note    : none
* @time     : 2023/07/01 15:15:35
*************************************************************************************/
void logo_proc() // logo界面处理函数
{
    if (key_msg.pressed)
    {
        key_msg.pressed = false;
        ui_state = S_DISAPPEAR;
        ui_index = M_SELECT;
    }
    logo_ui_show();
}

void select_proc(void) // 选择界面处理
{
    if (key_msg.pressed)
    {
        key_msg.pressed = false;
        switch (key_msg.id)
        {
        case 0:
            if (ui_select < 1)
                break;
            ui_select -= 1;
            line_y_trg -= single_line_length;
            if (ui_select < -(y / 16)){
                y_trg += 16;
            }
            else{
                box_y_trg -= 16;
            }
            break;
        case 1:
            if ((ui_select + 2) > (sizeof(list) / sizeof(SELECT_LIST)))
                break;
            ui_select += 1;
            line_y_trg += single_line_length;
            if ((ui_select + 1) > (4 - y / 16)){
                y_trg -= 16;
            }
            else{
                box_y_trg += 16;
            }
            break;
        case 2:
            switch (ui_select)
            {
            case 0: // return
                ui_state = S_DISAPPEAR;
                ui_index = M_LOGO;
                break;
            case 1: // Terminal
                ui_state = S_DISAPPEAR;
                ui_index = M_TERMINAL;
                break;
            case 2: // Icon
                ui_state = S_DISAPPEAR;
                ui_index = M_ICON;
                break;
            case 3: // BuzzerMusic
                ui_state = S_DISAPPEAR;
                ui_index = M_BUZZERMUSIC;
                break;
            case 4: // about
                ui_state = S_DISAPPEAR;
                ui_index = M_ABOUT;
                break;
            }
        default:
            break;
        }
        box_width_trg = u8g2.getStrWidth(list[ui_select].select) + x * 2;
    }
    select_ui_show();
}

void icon_action(uint8_t selectIcon){
    switch (selectIcon)
    {
    case 3:
        ui_state = S_DISAPPEAR;
        ui_index = M_SELECT;
        icon_select = 0;
        icon_x = icon_x_trg = 0;
        app_y = app_y_trg = 0;
        break;
    case 0:
        LED.Toggle();
        break;
    case 1:
        LED.OFF();
        break;
    case 2:
        LED.ON();
        break;
    }
}

void icon_proc(void) // icon界面处理
{
    icon_ui_show();
    if (key_msg.pressed)
    {
        key_msg.pressed = false;
        switch (key_msg.id)
        {
        case 1:
            if (icon_select != (icon_num - 1))
            {
                icon_select += 1;
                app_y_trg += 16;
                icon_x_trg -= ICON_SPACE;
            }
            break;
        case 0:
            if (icon_select != 0)
            {
                icon_select -= 1;
                app_y_trg -= 16;
                icon_x_trg += ICON_SPACE;
            }
            break;
        case 2:
            icon_action(icon_select);
            break;
        }
    }
}

void about_proc() // about界面处理函数
{
    about_ui_show();
    if (key_msg.pressed)
    {
        key_msg.pressed = false;
        ui_state = S_DISAPPEAR;
        ui_index = M_SELECT;
    }
}

void icon_motor_action(uint8_t selectIcon){
    static uint8_t InTime = 0;
    switch (selectIcon)
    {
    case 3:
        ui_state = S_DISAPPEAR;
        ui_index = M_SELECT;
        icon_select = 0;
        icon_x = icon_x_trg = 0;
        app_y = app_y_trg = 0;
        break;
    case 0:
        InTime = 1 - InTime;
        if(InTime) sendCommond(0);
        if(!InTime) sendCommond(2);
        break;
    case 1:
        InTime = 1 - InTime;
        if(InTime) sendCommond(1);
        if(!InTime) sendCommond(2);
        break;
    case 2:
        InTime = 1 - InTime;
        if(InTime) sendCommond(3);
        if(!InTime) sendCommond(4);
        break;
    }
}

void terminal_proc(void) // 终端显示界面
{
    if (key_msg.pressed)
    {
        key_msg.pressed = false;
        switch (key_msg.id)
        {
        case 1:
            if (icon_select != (icon_num - 1))
            {
                icon_select += 1;
                app_y_trg += 16;
                icon_x_trg -= ICON_SPACE;
            }
            break;
        case 0:
            if (icon_select != 0)
            {
                icon_select -= 1;
                app_y_trg -= 16;
                icon_x_trg += ICON_SPACE;
            }
            break;
        case 2:
            icon_motor_action(icon_select);
            break;
        }
    }
    terminal_ui_show();
}

void icon_buzzer_action(uint8_t selectIcon){
    switch (selectIcon)
    {
    case 3:
        ui_state = S_DISAPPEAR;
        ui_index = M_SELECT;
        icon_select = 0;
        icon_x = icon_x_trg = 0;
        app_y = app_y_trg = 0;
        break;
    case 0:
        BEEP.Play_mario();
        break;
    case 1:
        BEEP.Play_jingle();
        break;
    case 2:
        BEEP.Play_music();
        break;
    }
}

void buzzer_music_proc(void) // 蜂鸣器播放音乐界面
{
    if (key_msg.pressed)
    {
        key_msg.pressed = false;
        switch (key_msg.id)
        {
        case 1:
            if (icon_select != (icon_num - 1))
            {
                icon_select += 1;
                app_y_trg += 16;
                icon_x_trg -= ICON_SPACE;
            }
            break;
        case 0:
            if (icon_select != 0)
            {
                icon_select -= 1;
                app_y_trg -= 16;
                icon_x_trg += ICON_SPACE;
            }
            break;
        case 2:
            icon_buzzer_action(icon_select);
            break;
        }
    }
    buzzer_music_ui_show();
}

/*************************************************************************************
* @note    : 总的初始化和界面控制函数 
* @note    : none 
* @note    : none 
* @note    : none
* @time     : 2023/07/01 15:16:05
*************************************************************************************/
void ui_proc()
{
    switch (ui_state)
    {
    case S_NONE:
        u8g2.clearBuffer();
        switch (ui_index)
        {
        case M_LOGO:
            logo_proc();
            break;
        case M_SELECT:
            select_proc();
            break;
        case M_TERMINAL:
            terminal_proc();
            break;
        case M_ICON:
            icon_proc();
            break;
        case M_BUZZERMUSIC:
            buzzer_music_proc();
            break;
        case M_ABOUT:
            about_proc();
            break;
        }
        break;
    case S_DISAPPEAR:
        disappear();
        break;
    }
    u8g2.sendBuffer();
}
