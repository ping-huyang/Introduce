#ifndef __KEY_H__
#define __KEY_H__
#include "common.h"

/*************************************************************************************
* @note    : none 
* @note    : none 
* @note    : none 
* @note    : none
* @time     : 2023/07/01 14:50:33
*************************************************************************************/
// 按键变量
typedef struct
{
    bool val;
    bool last_val;
} KEY;

// 按键信息
typedef struct
{
    uint8_t id;
    bool pressed;
} KEY_MSG;

void Key_Meun_Init(void);
void Key_Meun_Scan(void);

extern KEY key[];
extern KEY_MSG key_msg;

/*************************************************************************************
* @note    : none 
* @note    : none 
* @note    : none 
* @note    : none
* @time     : 2023/07/01 14:50:14
*************************************************************************************/
#define KEY1_Pin 5
#define KEY2_Pin 18
#define KEY3_Pin 19
#define KEY4_Pin 23
#define Touch_KEY T7

#define KEY1 digitalRead(5)
#define KEY2 digitalRead(18)
#define KEY3 digitalRead(19)
#define KEY4 digitalRead(23)

typedef void (*KeyFuncPrt)(void);

void Key_OneButton_Init(void);
void Key_OneButton_Scan(uint16_t delay_Time_ms);

uint16_t Touch_Key_Value(void);

void KEY_Init(void);
uint8_t KEY_Scan(uint8_t mode);

extern uint8_t KEY_Number;
extern KeyFuncPrt keyAction[];

#endif
