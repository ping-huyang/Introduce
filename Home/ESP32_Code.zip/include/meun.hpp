#ifndef __MEUN_H__
#define __MEUN_H__
#include "common.h"

#define SPEED 4       // 16的因数
#define ICON_SPEED 12 // 图标的移动速度
#define ICON_SPACE 48 // 图标间隔，speed倍数

enum
{
    M_LOGO,         // 开始界面
    M_SELECT,       // 选择界面
    M_TERMINAL,     // 控制台界面
    M_ICON,         // icon界面
    M_BUZZERMUSIC,  // 无源蜂鸣器播放音乐界面
    M_ABOUT,        // 关于本机
};

enum
{
    S_NONE,
    S_DISAPPEAR,
    S_SWITCH,
    S_MENU_TO_MENU,
    S_MENU_TO_PIC,
    S_PIC_TO_MENU,
};

typedef struct
{
    const char *select;
} SELECT_LIST;

void Meun_Init(void);
void ui_proc(void);

extern U8G2_SSD1306_128X64_NONAME_F_HW_I2C u8g2;

#endif
