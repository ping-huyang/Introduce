#ifndef __COMMON_H__
#define __COMMON_H__

#include <Arduino.h>
#include <U8g2lib.h>
#include "key.hpp"
#include "gpio.hpp"
#include "meun.hpp"
#include "usart_2.hpp"

#endif