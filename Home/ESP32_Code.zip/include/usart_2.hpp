#ifndef __USART_2__
#define __USART_2__
#include "common.h"

void sendCommond(uint8_t commond);

#endif
