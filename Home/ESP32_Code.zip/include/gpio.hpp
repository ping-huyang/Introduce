#ifndef __GPIO_H__
#define __GPIO_H__
#include <Arduino.h>

#define LED_Pin 2
#define BEEP_Pin 4

/*************************************************************************************
* @note    : LED封装类 
* @note    : none 
* @note    : none 
* @note    : none
* @time     : 2023/06/29 21:09:31
*************************************************************************************/
class MY_LED
{
public:
    MY_LED(uint8_t pin){
        ledPin = pin;
        pinMode(pin,OUTPUT);
        digitalWrite(pin,LOW);
    }

    void ON(void);
    void OFF(void);
    void Toggle(void);

private:
    uint8_t ledPin;
};


/*************************************************************************************
* @note    : 无源蜂鸣器封装类 
* @note    : none 
* @note    : none 
* @note    : none
* @time     : 2023/06/29 21:09:24
*************************************************************************************/
class MY_BEEP
{
public:
    MY_BEEP(uint8_t sig_pin) : pwm_pin(sig_pin){
        ledcSetup(pwm_channel, frequency, resolution);
        ledcAttachPin(pwm_pin, pwm_channel);
    }

    void play(const uint16_t *melodies, size_t size, unsigned long wait, uint16_t duty);
    void play(const uint16_t note, unsigned long wait , uint16_t duty);
    void play(const uint16_t note, uint16_t duty);
    void Play_mario(void);
    void Play_jingle(void);
    void Play_music(void);

private:
    const uint8_t pwm_channel = 0;
    const uint8_t resolution = 10;
    uint8_t pwm_pin;
    uint16_t frequency = 2000;
};

extern MY_LED LED;
extern MY_BEEP BEEP;

#endif
