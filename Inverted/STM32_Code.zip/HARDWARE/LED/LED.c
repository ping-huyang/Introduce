#include "stm32f10x.h"
#include "led.h"
#include "delay.h"

/*************************************************************************************
* @note    : ���СLED���ƴ��� 
* @note    : none 
* @note    : none 
* @note    : none
* @time     : 2023/04/19 23:42:35
*************************************************************************************/
void LED_Init()
{
	RCC_APB2PeriphClockCmd(LED_CLOCK,ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Pin = LED_PIN;
	GPIO_Init(LED_PORT,&GPIO_InitStructure);
	GPIO_SetBits(LED_PORT,LED_PIN);
}

void LED_ON()
{
    GPIO_ResetBits(LED_PORT,LED_PIN);
}

void LED_OFF()
{
    GPIO_SetBits(LED_PORT,LED_PIN);
}

void LED_TOGGLE_LEVEL(void)
{
    GPIO_WriteBit(LED_PORT,LED_PIN,(BitAction)(1-GPIO_ReadOutputDataBit(LED_PORT,LED_PIN)));
}

void LED_Blink()
{
	for(int i = 0 ; i < 5 ; i++)
	{
		GPIO_ResetBits(LED_PORT,LED_PIN);
		delay_ms(100);
		GPIO_SetBits(LED_PORT,LED_PIN);
		delay_ms(100);
	}
}

