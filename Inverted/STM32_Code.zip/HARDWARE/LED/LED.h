#ifndef __LED_H__
#define __LED_H__
#include "sys.h"

#define LED_CLOCK RCC_APB2Periph_GPIOA
#define LED_PORT GPIOA
#define LED_PIN GPIO_Pin_4

#define LED PAout(4)

void LED_ON(void);
void LED_OFF(void);
void LED_TOGGLE_LEVEL(void);
void LED_Blink(void);
void LED_Init(void);

#endif

