#include "Motor.h"

/**
* @brief    : 直流电机初始化，需要一个pwm引脚和，两个控制转向的引脚 
* @param    : none 
* @return   : none 
* @author   : HuYang
* @note     : 2023/04/20 10:13:20
**/
void Motor_Init(void)
{
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12|GPIO_Pin_13;
	GPIO_Init(GPIOB,&GPIO_InitStructure);
	GPIO_ResetBits(GPIOB,GPIO_Pin_12);
    GPIO_ResetBits(GPIOB,GPIO_Pin_13);
    PWM_Init();
}

/**
* @brief    : 设置电机的pwm，pwm正负控制方向 
* @param    : none 
* @return   : none 
* @author   : HuYang
* @note     : 2023/04/20 11:06:55
**/
void MOTOR_SetPwmValue(int16_t duty)
{
    if(duty >= 0)
    {
        if(duty >= MOTOR_PWM_MAX)
            duty = MOTOR_PWM_MAX;
        GPIO_SetBits(GPIOB,GPIO_Pin_13);
        GPIO_ResetBits(GPIOB,GPIO_Pin_12);
        PWM_SetCompare(duty);
    }
    if(duty < 0)
    {
        if(duty <= -MOTOR_PWM_MAX)
            duty = -MOTOR_PWM_MAX;
        duty = -duty;
        GPIO_ResetBits(GPIOB,GPIO_Pin_13);
        GPIO_SetBits(GPIOB,GPIO_Pin_12);
        PWM_SetCompare(duty);
    }
}

