#ifndef __MOTOR_H__
#define __MOTOR_H__
#include "common.h"

//100%占空比对应7200
#define MOTOR_PWM_MAX 6500
#define BIN1 PBout(13)
#define BIN2 PBout(12)

void Motor_Init(void);
void MOTOR_SetPwmValue(int16_t duty);

#endif

