#include "serial.h"

/*************************************************************************************
* @note    : 单个Button按下之后的回调函数 
* @note    : none 
* @note    : none 
* @note    : none
* @time     : 2023/06/01 10:58:32
*************************************************************************************/
FuncPtr ButtonFunction[] = {
    Button_LED_ON,
    Button_LED_OFF,
    Button_LQR_ON,
    Button_LQR_OFF,
    Button_PID_ON,
    Button_PID_OFF,
    Button_Left_MOVE,
    Button_Right_MOVE,
    Button_OLED_PageAdd,
    Button_OLED_PageReduce,
    PID_Left_Move,
    PID_Right_Move,
    APP_Variable_Show,
    APP_Variable_Close
};

void Button_LED_ON(void)
{
    printf("Button_LED_ON\r\n");
    LED_ON();
}

void Button_LED_OFF(void)
{
    printf("Button_LED_OFF\r\n");
    LED_OFF();
}

void Button_LQR_ON(void)
{
    printf("Button_LQR_ON\r\n");
    LQR_Variable_Clear();
    LQR.Begain = 1;
}

void Button_LQR_OFF(void)
{
    printf("Button_LQR_OFF\r\n");
    LQR.Begain = 0;
    MOTOR_SetPwmValue(0);
}

void Button_PID_ON(void)
{
    printf("Button_PID_ON\r\n");
    PID.Begain_Smooth = 1;
}

void Button_PID_OFF(void)
{
    printf("Button_PID_OFF\r\n");
    PID_Smooth_Stop();
}

void Button_Left_MOVE(void)
{
    printf("Button_Left_MOVE\r\n");
    LQR.offset += 0.05;
}

void Button_Right_MOVE(void)
{
    printf("Button_Right_MOVE\r\n");
    LQR.offset -= 0.05;
    if(LQR.offset <= 0)
        LQR.offset = 0;
}

void Button_OLED_PageAdd(void)
{
    printf("Button_OLED_ADD");
    OLED_PageAdd();
}

void Button_OLED_PageReduce(void)
{
    printf("Button_OLED_PageReduce");
    OLED_PageReduce();
}

void PID_Left_Move(void)
{
    printf("PID_Left_Move");
    Position_PID.input += 200;
}

void PID_Right_Move(void)
{
    printf("PID_Right_Move");
    Position_PID.input -= 200;
}

void APP_Variable_Show(void)
{
    printf("APP_Variable_Show");
    APP_ShowVariable = 1;
}

void APP_Variable_Close(void)
{
    printf("APP_Variable_Close");
    APP_ShowVariable = 0;
}


/*************************************************************************************
* @note    : 修改单个Float型参数 
* @note    : none 
* @note    : none 
* @note    : none
* @time     : 2023/06/01 10:59:01
*************************************************************************************/
floatBytes Variable;

FuncPtr2 ButtonChangeVariable[] = {
    ChangVariable,
    ChangVariable,
    ChangVariable,
    ChangVariable,
    ChangVariable,
    ChangVariable
};

void BytesToFloat(u8* Value)
{
    Variable.b[0] = Value[0];
    Variable.b[1] = Value[1];
    Variable.b[2] = Value[2];
    Variable.b[3] = Value[3];
}

void ChangVariable(u8 whichOne , u8* Value)
{
    BytesToFloat(Value);
    // 收到的float参数是：Variable.f 
    printf("receive float is : %f\r\n", Variable.f);

    //根据具体的whichOne参数，修改具体值
    printf("wichOne = %d\r\n", whichOne);

    switch (whichOne)
    {
    case 0:
        Angle_PID.kp = Variable.f;
        OLED_PageChange(1);
        break;
    case 1:
        Angle_PID.kd = Variable.f;
        OLED_PageChange(1);
        break;
    case 2:
        Position_PID.kp = Variable.f;
        OLED_PageChange(1);
        break;
    case 3:
        Position_PID.kd = Variable.f;
        OLED_PageChange(1);
        break;
    case 4:
        printf("待定");
        break;
    case 5:
        printf("待定");
        break;
    }
}

