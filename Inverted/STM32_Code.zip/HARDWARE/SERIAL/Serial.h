#ifndef __SERIAL_H__
#define __SERIAL_H__
#include "common.h"

typedef void (*FuncPtr)(void);
typedef void (*FuncPtr2)(u8 whichOne, u8* Value);

void Serial_Loop(void);
void CommendParse(u8* commend);
void Serial_Display_Variable(void);
void print_Receive_Text(uint8_t *data, uint32_t len);

void Button_LED_ON(void);
void Button_LED_OFF(void);
void Button_LQR_ON(void);
void Button_LQR_OFF(void);
void Button_PID_ON(void);
void Button_PID_OFF(void);
void Button_Left_MOVE(void);
void Button_Right_MOVE(void);
void Button_OLED_PageAdd(void);
void Button_OLED_PageReduce(void);
void PID_Left_Move(void);
void PID_Right_Move(void);
void APP_Variable_Show(void);
void APP_Variable_Close(void);

void ChangVariable(u8 whichOne, u8* Value);

extern FuncPtr ButtonFunction[];
extern FuncPtr2 ButtonChangeVariable[];
extern u8 APP_ShowVariable;

#endif
