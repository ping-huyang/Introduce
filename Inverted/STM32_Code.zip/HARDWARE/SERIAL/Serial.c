#include "serial.h"

/*************************************************************************************
* @note    : 处理来自于客户端的数据信息 
* @note    : none 
* @note    : none 
* @note    : none
* @time     : 2023/05/27 21:46:52
*************************************************************************************/

/**
* @brief    : 打印接收到的信息 
* @param    : none 
* @return   : none 
* @author   : HuYang
* @note     : 2023/06/01 14:40:24
**/
void print_Receive_Text(uint8_t *data, uint32_t len) 
{
    char str[len + 1];
    for (uint32_t i = 0; i < len; i++) {
        str[i] = (char)data[i];
    }
    str[len] = '\0';
    printf("Receive :  %s\n", str);
}

/**
* @brief    : 放在主循环里面，用于处理接收串口数据处理 
* @param    : none 
* @return   : none 
* @author   : HuYang
* @note     : 2023/06/01 17:20:51
**/
void Serial_Loop(void)
{
    if(Serial.isfinished)
    {
        CommendParse(Serial.receiveBuf);
        //每次接收完成之后，做一次缓寸清空操作
        for(uint8_t i = 0 ; i < BUF_LENGTH ; i++) Serial.receiveBuf[i] = 0;
        Serial.index = 0;
        Serial.isStart = 0;
        Serial.OK_Times ++;
        Serial.isfinished = 0;
    }
}


/**
* @brief    : 处理接收到的数据 
* @param    : none 
* @return   : none 
* @author   : HuYang
* @note     : 2023/05/27 22:13:19
**/

void CommendParse(u8* commend)
{    
    printf("Coming into CommendParse\r\n");
    printf("Receive Commend is : \r\n[ ");
    for(int i = 0 ; i < commend[2] + 4 ; i ++)
        printf("%02x ", commend[i]);
    printf("] ");

    // 开关按键控制
	if(commend[1] == 0xAB)
    {
        printf("Doing Button_Cliked\r\n");
        ButtonFunction[commend[3]]();
    }

   // 修改单个参数处理 
    if(commend[1] == 0xCD)
    {
        printf("Doing Button_Change_Variable\r\n");
        static u8 Value[4], i;
        for(i = 0; i < 4 ; i++) Value[i] = commend[i + 4];
        ButtonChangeVariable[commend[3]](commend[3],Value);
    }
}


/*************************************************************************************
* @note    : 串口发送float型数据 
* @note    : none 
* @note    : none 
* @note    : none
* @time     : 2023/06/02 08:58:28
*************************************************************************************/
#define SEND_FLOAT_SIZE 5
#define BUF_SIZE (SEND_FLOAT_SIZE*4 + 1)

u8 APP_ShowVariable = 0;
floatBytes TempFloat;
u8 Buf[BUF_SIZE] = {0xF3};
float sentFloat[SEND_FLOAT_SIZE] = {0};

void Serial_Display_Variable(void)
{
    sentFloat[0] = (float)Angle_average;
    sentFloat[1] = (float)LQR.x;
    sentFloat[2] = (float)LQR.x_speed;
    sentFloat[3] = (float)LQR.angle;
    sentFloat[4] = (float)LQR.angle_speed;

    Buf[0] = 0xF3;
    for(u8 i = 0 ; i < SEND_FLOAT_SIZE ; i++)
    {
        TempFloat.f = sentFloat[i];
        Buf[4*i+1] = TempFloat.b[0];
        Buf[4*i+2] = TempFloat.b[1];
        Buf[4*i+3] = TempFloat.b[2];
        Buf[4*i+4] = TempFloat.b[3];
    }
    Serial_SendArray(Buf, BUF_SIZE);
}
