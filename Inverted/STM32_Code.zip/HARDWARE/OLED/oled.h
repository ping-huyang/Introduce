#ifndef __OLED_H
#define __OLED_H	
#include "sys.h"
#include "delay.h"		  	 

//-----------------OLED�˿ڶ���---------------- 
#define OLED_RST_Clr() PBout(3)=0   //RST
#define OLED_RST_Set() PBout(3)=1   //RST

#define OLED_RS_Clr() PAout(15)=0    //DC
#define OLED_RS_Set() PAout(15)=1    //DC

#define OLED_SCLK_Clr()  PBout(5)=0  //SCL
#define OLED_SCLK_Set()  PBout(5)=1   //SCL

#define OLED_SDIN_Clr()  PBout(4)=0   //SDA
#define OLED_SDIN_Set()  PBout(4)=1   //SDA

#define OLED_CMD  0	//д����
#define OLED_DATA 1	//д����

//OLED�����ú���
void OLED_WR_Byte(u8 dat,u8 cmd);	    
void OLED_Display_On(void);
void OLED_Display_Off(void);
void OLED_Refresh_Gram(void);		   				   		    
void OLED_Init(void);
void OLED_Clear(void);
void OLED_DrawPoint(u8 x,u8 y,u8 t);
void OLED_Char(u8 x,u8 y,u8 chr,u8 size,u8 mode);
void OLED_Number(u8 x,u8 y,u32 num,u8 len,u8 size);
void OLED_SignedNumber(u8 x,u8 y,int32_t Number,u8 Length,u8 size);
void OLED_String(u8 x,u8 y,const u8 *p ,u8 size);

void OLED_Fresh(void);
void OLED_SizeModel(u8 size, u8 model);
void OLED_ShowChar(u8 row , u8 list , u8 chr);
void OLED_ShowUnsignedInt(u8 row , u8 list , uint32_t num , u8 len);
void OLED_ShowInt(u8 row , u8 list , int32_t num , u8 len);
void OLED_ShowString(u8 row , u8 list , const u8* str);

void OLED_ShowFloat(u8 row, u8 list , float f , u8 len1 , u8 len2);

#endif  
	 
