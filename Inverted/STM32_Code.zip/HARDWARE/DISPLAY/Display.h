#ifndef __DISPLAY_H__
#define __DISPLAY_H__
#include "common.h"

typedef union {
  float f;
  uint8_t b[4];
} floatBytes;

typedef union {
  int16_t int16bit;
  uint8_t b[2];
} int16Bytes;

typedef struct 
{
    u8 Page;
    u8 FirstIN;
}OLED_Param;

typedef void (*PagePtr)(void);

void OLED_Refresh(void);
void OLED_PageChange(u8 page);
void OLED_PageAdd(void);
void OLED_PageReduce(void);

void Display_Int16Img(void);
void Display_FloatImg(void);

extern OLED_Param OLED;

#endif

