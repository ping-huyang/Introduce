#ifndef __LQR_BALANCE_H__
#define __LQR_BALANCE_H__
#include "common.h"
#include <string.h>

#define PI 3.14159265
#define ZHONGZHI 3100
#define FILTERING_TIMES  4
#define POSITION_MIDDLE 7925
#define ANGLE_ORIGIN 1020
#define ANGLE_MIDDLE 3145

typedef struct
{
    u8    Begain,stop,count_0,count_1,count_2,label,step;
    int   Encoder,last_Encoder,Moto_PWM,Direction;
    float t, x, x_speed, angle, angle_speed, u, Angle_Balance;  // t,位移,速度,角度,角速度,电压
    float last_x_speed, last_angle, last_angle_speed;           // 记录参数值
    float k1, k2, k3, k4;                                       // LQR状态反馈系数
    float a, k, offset;                                         // 按键修改摆杆运动的值
}LQR_Param;

void LQR_Stop(void);
void LQR_Control(void);
void LQR_Variable_Init(void);
void LQR_Variable_Clear(void);

extern LQR_Param LQR;

#endif

