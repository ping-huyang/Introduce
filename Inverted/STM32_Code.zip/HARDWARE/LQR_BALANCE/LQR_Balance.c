#include "LQR_Balance.h"

/*************************************************************************************
* @note    : LQR+能量自起摆 
* @note    : none 
* @note    : none 
* @note    : none
* @time     : 2023/05/27 09:05:41
*************************************************************************************/
LQR_Param LQR;

/**
* @brief    : LQR参数初始化 
* @param    : none 
* @return   : none 
* @author   : HuYang
* @note     : 2023/05/27 17:40:55
**/
void LQR_Variable_Init(void)
{
    LQR.Begain = 0; //开始标志位
    LQR.t = 0.020;
    LQR.k1 = -64.3246;
    LQR.k2 = -51.7069;
    LQR.k3 = -109.4812;
    LQR.k4 = -19.5620;
    LQR.last_Encoder = 10000;
    LQR.label = 1;
    LQR.step = 1;
    LQR.Direction = 1;
    LQR.a = 1.0;
    LQR.k = 3.5;
    LQR.offset = 0.15;
}

void LQR_Variable_Clear(void)
{
    memset(&LQR, 0, sizeof(LQR));
    LQR_Variable_Init();
}

void LQR_Stop(void)
{
    LQR.Begain = 0;
    LQR_Variable_Clear();
}

float Angle_Count(float angle_adc)
{
    long int angle_int;
    float angle;
    angle_int = 3100 - angle_adc;
    angle = angle_int * 0.0879f;
    if (angle_adc >= 0 && angle_adc <= 1052)
    {
        angle -= 360;
    }
    return angle;
}

void LQR_Control(void)
{
    // 获得编码器的值和角度原始值
    LQR.Encoder = (int)Position_Encoder;
    LQR.Angle_Balance = (float)Angle_average;

    // 计算速度
    LQR.x_speed = (((LQR.last_Encoder - LQR.Encoder) / 1040.0f) * 0.036 * PI) / LQR.t;
    LQR.x_speed = LQR.a * LQR.x_speed + (1 - LQR.a) * LQR.last_x_speed;
    LQR.last_x_speed = LQR.x_speed;

    // 计算出实际移动的位置
    LQR.x += (((LQR.last_Encoder - LQR.Encoder) / 1040.0f) * 0.036 * PI);
    LQR.last_Encoder = LQR.Encoder;

    // 角度值计算
    LQR.angle = Angle_Count(LQR.Angle_Balance) / 180.0f * PI;

    // 角速度计算
    LQR.angle_speed = (LQR.angle - LQR.last_angle) / LQR.t;
    LQR.angle_speed = LQR.a * LQR.angle_speed + (1 - LQR.a) * LQR.last_angle_speed;
    LQR.last_angle_speed = LQR.angle_speed;
    LQR.last_angle = LQR.angle;

    // 能量起摆和LQR稳定控制
    if (LQR.angle > -0.3491 && LQR.angle < 0.3491)
    {
        if (LQR.count_0 < 100)
            LQR.count_0 += 1;
        if (LQR.count_0 == 100)
            LQR.a = 0.4, LQR.count_0++;
        LQR.u = -(LQR.k1 * (LQR.x + LQR.offset) + LQR.k2 * LQR.x_speed + LQR.k3 * LQR.angle + LQR.k4 * LQR.angle_speed); // 稳摆
        LQR.Moto_PWM = (int)(7200 * (LQR.u / 12.0f));
    }else
    {
        LQR.a = 1.0;
        LQR.count_0 = 0;
        if (LQR.step == 1)
        {
            if (LQR.x > 0.1)
            {
                LQR.Direction = -1;
            }
            else if (LQR.x < -0.1)
            {
                LQR.label = 0;
                LQR.Direction = 1;
            }
            if (LQR.label == 0 & LQR.x > 0)
            {
                LQR.Direction = 0;
                LQR.step = 2;
            }
            LQR.Moto_PWM = LQR.Direction * 3600;
        }
        else if (LQR.step == 2)
        {
            if (LQR.count_1 < 1)
                LQR.count_1 += 1;
            if (LQR.Angle_Balance > (ANGLE_MIDDLE - 512) && LQR.Angle_Balance < (ANGLE_MIDDLE + 512) && LQR.k == 3.5)
                LQR.k = 2.5;
            if (LQR.Angle_Balance > 0 && LQR.Angle_Balance < 2048 && LQR.count_1 == 1){
                if (LQR.count_2 == 50)
                    LQR.stop = 0, LQR.count_2 = 0;
                if (LQR.stop)
                    LQR.count_2 += 1;
                else
                    LQR.Moto_PWM = -LQR.k * (LQR.Angle_Balance - ANGLE_ORIGIN);
            }else{
                LQR.Moto_PWM = 0;
            }
        }
    }

    // 限制幅值
    if(LQR.Moto_PWM > MOTOR_PWM_MAX) LQR.Moto_PWM = MOTOR_PWM_MAX;
    if(LQR.Moto_PWM < -MOTOR_PWM_MAX) LQR.Moto_PWM = -MOTOR_PWM_MAX;

    // 开关控制是否进行LQR控制
    MOTOR_SetPwmValue(LQR.Moto_PWM);
}
