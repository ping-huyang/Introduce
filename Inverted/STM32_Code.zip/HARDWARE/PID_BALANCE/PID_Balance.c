#include "PID_Balance.h"

/*************************************************************************************
* @note    : 本文件为倒立摆控制的核心算法，*****，最最重要的环节 
* @note    : 2023.4.21 预计完成任务点：1、先完成pid控制模型建立和代码实现，让倒立摆扶正的情况下稳定
                                      2、完成1之后，完成一阶倒立摆自己摆上去然后稳定
                                      3、调节、优化、极点配置等等
* @note    : 初步实现思路，两个pid控制环，一个角度环用于将摆杆立起来，一个位置环控制小车位置 
* @note    : none
* @time     : 2023/04/21 20:04:42
*************************************************************************************/

PID_Parm Angle_PID,Position_PID;
CONTROL PID;

/**
* @brief    : 初始化参数
* @param    : none 
* @return   : none 
* @author   : HuYang
* @note     : 2023/04/21 20:09:35
**/
void PID_Variable_Init(void)
{
    PID.Begain_Smooth = 0;
    PID.Begain_Auto = 0;
    Angle_PID.kp = ANGLE_INIT_KP;
    Angle_PID.kd = ANGLE_INIT_KD;
    Angle_PID.input = ANGLE_INIT_CONTROL_POSITION;
    Position_PID.kp = POSITION_INIT_KP;
    Position_PID.kd = POSITION_INIT_KD;
    Position_PID.input = POSITION_TARGE_POSITION;
}

/**
* @brief    : 参数清除工作 
* @param    : none 
* @return   : none 
* @author   : HuYang
* @note     : 2023/04/23 21:28:56
**/
void PID_Variable_Clear(void)
{
    MOTOR_SetPwmValue(0);
    TIM_SetCounter(TIM4, 0);
    PID.final_PWM = 0;
    memset(&Position_PID, 0, sizeof(Position_PID));
    memset(&Angle_PID, 0, sizeof(Angle_PID));
    Angle_PID.kp = ANGLE_INIT_KP;
    Angle_PID.kd = ANGLE_INIT_KD;
    Angle_PID.input = ANGLE_INIT_CONTROL_POSITION;
    Position_PID.kp = POSITION_INIT_KP;
    Position_PID.kd = POSITION_INIT_KD;
    Position_PID.input = POSITION_TARGE_POSITION;
}

/**
* @brief    : 停止PID稳摆控制 
* @param    : none 
* @return   : none 
* @author   : HuYang
* @note     : 2023/06/01 19:45:19
**/
void PID_Smooth_Stop(void)
{
    PID.Begain_Smooth = 1 - PID.Begain_Smooth;
    PID_Variable_Clear();
}

/**
* @brief    : 运动过程中的意外情况给予保护措施 
* @param    : none 
* @return   : 返回0表示没有出现异常，1表示出现异常 
* @author   : HuYang
* @note     : 2023/04/23 21:46:16
**/
u8 Error_Test(void)
{
    static u8 count;
    if (Angle_average < (ANGLE_INIT_CONTROL_POSITION - 800) || Angle_average > (ANGLE_INIT_CONTROL_POSITION + 800) || Battery_Voltage < 700)
        count++;
    else
        count = 0;
    if (count == 120)
    {
        count = 0;
        return 1;
    }
    return 0;
}


/*************************************************************************************
* @note    : 稳定摆杆控制算法 
* @note    : none 
* @note    : none 
* @note    : none
* @time     : 2023/05/25 10:49:44
*************************************************************************************/
void PID_Smooth_Control(void)
{
    static u8 times = 0;

    // 角度PD控制
    Angle_PID.feedback = Angle_average;
    Angle_PID.error = Angle_PID.feedback - ANGLE_INIT_CONTROL_POSITION;
    Angle_PID.kp_term = Angle_PID.error;
    Angle_PID.kd_term = Angle_PID.error - Angle_PID.lastError;
    Angle_PID.lastError = Angle_PID.error;
    Angle_PID.output = -Angle_PID.kp*Angle_PID.kp_term - Angle_PID.kd*Angle_PID.kd_term;

    // 位置PD控制，25ms控制一次
    times ++;
    if(times >= 5){
        Position_PID.feedback = Position_Encoder - Position_PID.input;
        Position_PID.least = Position_PID.feedback;
        Position_PID.error *= 0.8;
        Position_PID.error += Position_PID.least * 0.2; //一阶滤波
        Position_PID.kp_term = Position_PID.error;
        Position_PID.kd_term = Position_PID.error - Position_PID.lastError;
        Position_PID.output = Position_PID.kp * Position_PID.kp_term + Position_PID.kd * Position_PID.kd_term;
        Position_PID.lastError = Position_PID.error;
        times = 0;
    }

    //计算机最终的PWM值，并进行限幅和保护
    PID.final_PWM = Angle_PID.output - Position_PID.output;
    if(PID.final_PWM > MOTOR_PWM_MAX) PID.final_PWM = MOTOR_PWM_MAX;
    if(PID.final_PWM < -MOTOR_PWM_MAX) PID.final_PWM = -MOTOR_PWM_MAX;

    //设置电机pwm值，以及异常检测停止系统
    if(Error_Test()){
        PID_Variable_Clear();
        PID.Begain_Smooth = 0;
    }else{
        MOTOR_SetPwmValue(PID.final_PWM);
    }
}




/*************************************************************************************
* @note    : PID起摆控制算法 
* @note    : none 
* @note    : none 
* @note    : none
* @time     : 2023/05/31 19:58:32
*************************************************************************************/
int Balance_Pwm, Position_Pwm; // 目标角度PWM、目标位置PWM
u8 Position_Target;            // 用于标记位置控制的时间
u8 Swing_up = 1;               // 用于标记手动起摆时，是否是第一次进入手动起摆函数
// 倾角PD控制所用到的参数
float Bias;              // 倾角偏差
float Last_Bias, D_Bias; // PID相关变量
int balance;             // PWM返回值
// 位置PD控制所用到的参数
float Position_PWM, Last_Position, Position_Bias, Position_Differential;
float Position_Least;
u8 auto_run = 0;          // 手动起摆或自动起摆标志位，默认是手动起摆
u8 autorun_step0 = 0;     // 自动起摆第0步，找到中点，等待起摆
u8 autorun_step1 = 1;     // 自动起摆第1步
u8 autorun_step2 = 0;     // 自动起摆第2步
long Target_Position;     // 目标位置
float D_Angle_Balance;    // 摆杆角度变化率
long success_count = 0;   // 摆杆在平衡位置的成功次数记录
u8 success_flag = 0;      // 自动起摆时满足平衡次数可以起摆的标志位
long wait_count = 0;      // 等待计数，计时时间到后，获取起摆成功的位置
long D_Count;             // 用于辅助获取摆杆角度变化率的中间变量
float Last_Angle_Balance; // 用于获取摆杆角度变化率函数中，保存上一次角度
u8 left, right;
u8 Flag_Stop=0,delay_50,delay_flag;         //停止标志位 50ms精准演示标志位
u8 system_start=0;                          //检测调节函数标志位
u8 tips_flag = 0;                           //OLED提示函数标志位
int Encoder,Position_Zero=10000;            //编码器的脉冲计数
int Moto;                                   //电机PWM变量 应是Motor的 向Moto致敬	
int Voltage;                                //电池电压采样相关的变量
float Angle_Balance;                        //角位移传感器数据
float Balance_KP=400,Balance_KD=400,Position_KP=20,Position_KD=300;  //PID系数
float Menu=1,Amplitude1=5,Amplitude2=20,Amplitude3=1,Amplitude4=10;  //PID调试相关参数

int Balance(float Angle)
{
    Bias = Angle - ZHONGZHI;                            // 求出平衡的角度中值 和机械相关
    D_Bias = Bias - Last_Bias;                          // 求出偏差的微分 进行微分控制
    balance = -Balance_KP * Bias - D_Bias * Balance_KD; //===计算倾角控制的电机PWM  PD控制
    Last_Bias = Bias;                                   // 保持上一次的偏差
    return balance;
}

int Pre_Position(int Encoder)
{
    static float Position_PWM, Last_Position, Position_Bias, Position_Differential;
    Position_Bias = Encoder - Position_Zero;                         //===得到偏差
    Position_Differential = Position_Bias - Last_Position;           // 偏差积分
    Last_Position = Position_Bias;                                   // 保存上一次偏差
    Position_PWM = Position_Bias * 25 + Position_Differential * 600; //===位置控制
    return Position_PWM;                                             // 返回值
}

int Incremental_PI(int Encoder, int Target)
{
    static float Bias, Pwm, Last_bias;
    Bias = Encoder - Target;                              // 计算偏差
    Pwm += 10 * (Bias - Last_bias) / 20 + 10 * Bias / 20; // 增量式PI控制器
    Last_bias = Bias;                                     // 保存上一次偏差
    return Pwm;                                           // 增量输出
}

int Position(int Encoder)
{
    Position_Least = Encoder - Position_Zero; //===
    Position_Bias *= 0.8;
    Position_Bias += Position_Least * 0.2; //===一阶低通滤波器
    Position_Differential = Position_Bias - Last_Position;
    Last_Position = Position_Bias;
    Position_PWM = Position_Bias * Position_KP + Position_Differential * Position_KD; //===速度控制
    return Position_PWM;
}

void Set_Pwm(int moto)
{
    MOTOR_SetPwmValue(moto);
}

void Xianfu_Pwm(void)
{
    int Amplitude = 6900; //===PWM满幅是7200 限制在6900
    if (Moto < -Amplitude)
        Moto = -Amplitude;
    if (Moto > Amplitude)
        Moto = Amplitude;
}

void Find_Zero(void)
{
    static float count;
    // 初始化时 autorun_step0=0，自然会执行
    if (autorun_step0 == 0) // 回到中位
    {
        Position_Zero = POSITION_MIDDLE; // 设置目标中间位置
        // 顺摆pid控制，让摆杆尽快稳定下来（目标角度是起始角，目标位置是起始位置）
        Balance_Pwm = Balance(Angle_Balance + 2070) / 8; // 倾角PD控制
        Position_Pwm = Pre_Position(Encoder);
        // 如果偏离了中点太多，开始PID控制缓慢调整
        if (Encoder < 7950)
            Moto = Incremental_PI(Encoder, POSITION_MIDDLE); // 位置闭环控制;//离开边缘地方再开始PID控制
        else
            Moto = -Balance_Pwm + Position_Pwm; // 读取PD控制器输出PWM
        // 判断角度和位置是否在原始位置，如果 检测到200次 在原始位置，即可以等待起摆
        // 等待起摆：把刚刚用过的标志位、电机pwm值全部清零，更新Target_Position=POSITION_MIDDL-668，这是自起摆时的第一个目标点，使autorun_step0=1不要再进入这个函数
        if (Angle_Balance < (ANGLE_ORIGIN + 300) && Angle_Balance > (ANGLE_ORIGIN - 300) && (Encoder > (POSITION_MIDDLE - 50) && Encoder < (POSITION_MIDDLE + 50)))
            count++;
        if (Angle_Balance < (ANGLE_ORIGIN + 300) && Angle_Balance > (ANGLE_ORIGIN - 300))
            count += 0.1;
        if (count > 200)
            autorun_step0 = 1, autorun_step1 = 0, Moto = 0, Target_Position = POSITION_MIDDLE - 668; // 摆杆运动到中间位置，停止 //设置目标位置，准备甩杆
    }
    // 对电机速度限幅，防止电机闭环位置控制过快
    if (Moto > 2500)
        Moto = 2500; // 控制位置闭环控制过程的速度
    if (Moto < -2500)
        Moto = -2500;
    Set_Pwm(Moto); // 控制电机
}

int Position_PID_Shit(int Encoder, int Target)
{
    Position_Least = Encoder - Target; //===
    Position_Bias *= 0.8;
    Position_Bias += Position_Least * 0.2; //===一阶低通滤波器
    Position_Differential = Position_Bias - Last_Position;
    Last_Position = Position_Bias;
    Position_PWM = Position_Bias * Position_KP + Position_Differential * Position_KD; //===速度控制
    return Position_PWM;
}

void Auto_run(void)
{
    static u8 speed = 0;
    static u8 help_count = 0;
    static u16 pid_adjust = 0;
    if (autorun_step1 == 0) // 自动起摆第一步 （第一次执行，一定是进入这里）
    {
        // 判断应该往哪一边换向
        if ((Angle_Balance > (ANGLE_ORIGIN - 120) && Angle_Balance < (ANGLE_ORIGIN + 120)))
        {
            if (D_Angle_Balance <= 0)
                right = 1;
            else if (D_Angle_Balance > 0)
                left = 1;
        }
        // 判断当摆杆回到初始位置时应该给出速度和位移
        if (left == 1)
        {
            if ((Angle_Balance > (ANGLE_ORIGIN - 50) && Angle_Balance < (ANGLE_ORIGIN + 50)))
            {
                left = 0;
                Target_Position = POSITION_MIDDLE + 800;
                if (speed > 1)
                    Target_Position = POSITION_MIDDLE + 160; // 让摆杆缓慢调节直至满足稳摆
            }
        }
        else if (right == 1)
        {
            if ((Angle_Balance > (ANGLE_ORIGIN - 50) && Angle_Balance < (ANGLE_ORIGIN + 50)))
            {
                right = 0;
                Target_Position = POSITION_MIDDLE - 482;
                if (speed > 1)
                    Target_Position = POSITION_MIDDLE - 160; // 让摆杆缓慢调节直至满足稳摆
            }
        }
        // 位置闭环控制
        Moto = Position_PID_Shit(Encoder, Target_Position);
        // 摆杆已经到达过平衡点附近，开始缓慢调节阶段。
        if (Angle_Balance < (ANGLE_MIDDLE + 385) && Angle_Balance > (ANGLE_MIDDLE - 385))
        {
            speed++;
        }
        // 判断当前情况是否符合起摆：起摆要素：位置不在边缘、角度在平衡点附近、角速度接近于0
        if (Angle_Balance < (ANGLE_MIDDLE + 120) && Angle_Balance > (ANGLE_MIDDLE - 120) && (Encoder > 6300 && Encoder < 9300) && (D_Angle_Balance > -30 && D_Angle_Balance < 30))
        {
            speed++;
            success_count++;
        }
        else
            success_count = 0; // 如果没在条件范围内，则需要重新清零等待下次判断
        // 满足3次起摆情况，标记可以成功起摆，并给出起摆瞬间的pid
        if (success_count > 3)
        {
            autorun_step1 = 1, success_flag = 1;
            Balance_KP = 210, Balance_KD = 150, Position_KP = 8, Position_KD = 130; // 自动起摆瞬间的pid参数
        }
        // 限幅
        if (Moto > 4100)
            Moto = 4100; // 控制位置闭环控制过程的速度
        if (Moto < -5100)
            Moto = -5100;
    }

    // 满足起摆条件，正常起摆
    else if (success_flag == 1) // 到最高点，起摆
    {
        if (wait_count == 0)
            Position_Zero = Encoder;          // 起摆前，先获取当前位置作为平衡的目标点
        Balance_Pwm = Balance(Angle_Balance); //===角度PD控制
        if (++Position_Target > 4)
            Position_Pwm = Position(Encoder), Position_Target = 0; //===位置PD控制 25ms进行一次位置控制
        // 起摆一段时间后，让摆杆缓慢恢复到中间点
        wait_count++;
        if (wait_count > 100 && wait_count < 2000)
        {
            if (Position_Zero > 8100)
                Position_Zero--;
            else if (Position_Zero < 8100)
                Position_Zero++;
        }
        if (wait_count > 2000)
            wait_count = 2001; // 锁住计数器值防止溢出循环

        // 起摆后调节pid阶段	 起摆瞬间与稳摆需要的pid参数不一样 所以当起摆成功进入稳摆后，即可以把pid参数调回稳摆时的数值
        if (help_count == 0)
        {
            pid_adjust++;
            if (pid_adjust % 100 == 0) // 缓慢调节 避免出现震荡失稳
            {
                Balance_KP += 10;
                Balance_KD += 10;
                Position_KP += 0.5;
                Position_KD += 10;
            }
            if (Balance_KP > 400)
                Balance_KP = 400;
            if (Balance_KD > 400)
                Balance_KD = 400;
            if (Position_KP > 20)
                Position_KP = 20;
            if (Position_KD > 300)
                Position_KD = 300;
            if (Balance_KP == 400 && Balance_KD == 400 && Position_KP == 20 && Position_KD == 300)
                help_count = 1; // 参数调节完毕后，释放pid数值限幅，此时用户可以通过按键改变pid参数
        }
        // 融合输出，最终效果
        Moto = Balance_Pwm - Position_Pwm; // 读取PD控制器输出PWM
    }
}

void PID_Action_Control(void)
{
    Angle_Balance = Angle_average;
    Encoder = Position_Encoder;
    
    if (Flag_Stop == 0)
    {
        Find_Zero();            // 起摆第0步，在边缘回到中点。函数内部实现只执行一次功能
        if (autorun_step0 == 1)
            Auto_run();         // 执行自动起摆
        Xianfu_Pwm();

        // 自动起摆步骤1中的滑块边缘保护
        if (autorun_step1 == 0 && (Encoder >= 9900 || Encoder <= 5900))
            Set_Pwm(0), Flag_Stop = 1;

        // 起摆成功后的角度保护，边缘保护
        if ((success_flag == 1) && ((!((Angle_Balance > ANGLE_MIDDLE - 600) && (Angle_Balance < ANGLE_MIDDLE + 600))) || (Encoder >= 9900 || Encoder <= 5900)))
            Set_Pwm(0), Flag_Stop = 1;
        else
            Set_Pwm(Moto);
    }

    if (Flag_Stop == 1)
        Set_Pwm(0);
}
