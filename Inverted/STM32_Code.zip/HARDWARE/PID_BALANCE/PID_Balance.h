#ifndef __PID_BALANCE_H__
#define __PID_BALANCE_H__
#include "common.h"

// 默认初始化PID
#define ANGLE_INIT_KP                   400    //初始化角度KP
#define ANGLE_INIT_KD                   400    //初始化角度KD
#define POSITION_INIT_KP                20.0f  //初始化位置KP
#define POSITION_INIT_KD                300.0f  //初始化位置KD

// 默认的其它控制参数
#define ANGLE_INIT_CONTROL_POSITION     3160  //稳住的角度AD值
#define POSITION_TARGE_POSITION         10000     //目标稳定位置

typedef struct
{
   	float kp,ki,kd;                                //PID参数
    float error,lastError,lastlastError,least;     //误差项
    float kp_term, ki_term, kd_term;               //PID三个分量
    int32_t output,input,feedback;                 //输出、输入、反馈
}PID_Parm;

typedef struct 
{
    u8 Begain_Smooth;   
    u8 Begain_Auto;                           
    int16_t final_PWM;                
}CONTROL;

void PID_Smooth_Control(void);
void PID_Action_Control(void);
void PID_Variable_Init(void);
void PID_Variable_Clear(void);
void PID_Smooth_Stop(void);

extern PID_Parm Angle_PID;
extern PID_Parm Position_PID;
extern CONTROL PID;


#define PI 3.14159265
#define ZHONGZHI 3100
#define FILTERING_TIMES  4
#define POSITION_MIDDLE 7925
#define ANGLE_ORIGIN 1020
extern	int Balance_Pwm,Velocity_Pwm;
extern float Bias;                       //倾角偏差
extern float Last_Bias,D_Bias;    //PID相关变量
extern int balance;                     //PWM返回值 
extern float Position_PWM,Last_Position,Position_Bias,Position_Differential;
extern float Position_Least;
void Set_Pwm(int moto);
void Xianfu_Pwm(void);
void Find_Zero(void);
void Auto_run(void);

#endif

