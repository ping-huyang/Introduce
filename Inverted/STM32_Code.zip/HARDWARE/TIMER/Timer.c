#include "Timer.h"

uint16_t _50ms_flag = 0; //由于AD滤波开启后，主函数延时出现bug，给主函数精准的50ms延时

/**
* @brief    : 定时器中断，用于定时获取编码器数据等功能
* @param    : none 
* @return   : none 
* @author   : HuYang
* @note     : 2023/04/21 18:15:36
**/
void Timer_Init(void)
{
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
    TIM_InternalClockConfig(TIM2);
    TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
    TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInitStructure.TIM_Period = 50 - 1;
    TIM_TimeBaseInitStructure.TIM_Prescaler = 7200 - 1;
    TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;
    TIM_TimeBaseInit(TIM2, &TIM_TimeBaseInitStructure);
    TIM_ClearFlag(TIM2, TIM_FLAG_Update);
    TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE);
    NVIC_InitTypeDef NVIC_InitStructure;
    NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_Init(&NVIC_InitStructure);
    TIM_Cmd(TIM2, ENABLE);
}


/**
* @brief    : 5ms定时器中断处理函数 
* @param    : none 
* @return   : none 
* @author   : HuYang
* @note     : 2023/04/21 18:15:27
**/
void TIM2_IRQHandler(void)
{
	if (TIM_GetITStatus(TIM2, TIM_IT_Update) == SET)
	{
        //led周期闪烁
		static uint8_t long_time = 0;
        long_time ++;_50ms_flag++;
        if(_50ms_flag >= 10) _50ms_flag = 0;
        if(long_time >= 100){
            long_time = 0;
            // LED_TOGGLE_LEVEL();
        }

        //刷新电源电压值和角度值以及位置信息
        //开启angle滤波之后在delay_us有问题，开启之后效果好很多
        AD_GetValue();
        Angle_average = AD_average_filter(10);
        Battery_Voltage = Battery_getVoltage();
        Position_Encoder = Encoder_Get();

        //25ms进行以此LQR平衡控制
        if(LQR.Begain)
        {
            static uint16_t times = 0;
            times ++;
            if(times >= 4)
            {
                times = 0;
                LQR_Control();
            }
        }

        //5ms进行一次PID稳摆控制
        if(PID.Begain_Smooth)
            PID_Smooth_Control();

        if(PID.Begain_Auto)
            PID_Action_Control();

        //清理中断标识位
		TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
	}
}



