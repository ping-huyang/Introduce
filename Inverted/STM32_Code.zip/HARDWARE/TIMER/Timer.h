#ifndef __TIMER_H
#define __TIMER_H
#include "common.h"

void Timer_Init(void);

extern uint16_t _50ms_flag;

#endif
