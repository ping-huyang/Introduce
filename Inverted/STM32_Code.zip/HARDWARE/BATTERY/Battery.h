#ifndef __BATTEY_H_
#define __BATTEY_H_
#include "common.h"

int Battery_getVoltage(void);
void Battery_showVoltage(void);

#endif

