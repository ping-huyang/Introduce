#include "Battery.h"

int Battery_getVoltage(void)
{
    return AD_Value[1]*3.3*11*100/1.0/4096;
}

void Battery_showVoltage(void)
{
    OLED_ShowString(1,1,"Vol:  .  V");
    OLED_ShowInt(1,5,Battery_Voltage/100,2);
    OLED_ShowInt(1,8,Battery_Voltage%100,2);
    OLED_Fresh();
}
