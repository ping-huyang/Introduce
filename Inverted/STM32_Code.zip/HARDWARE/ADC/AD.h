#ifndef __AD_H
#define __AD_H
#include "common.h"

#define  ADC_CHANNEL_SIZE 2	
	
void AD_Init(void);
void AD_GetValue(void);
uint16_t AD_average_filter(u8 times);
uint16_t filter_average(uint16_t f);

extern int Battery_Voltage;
extern uint16_t Angle_average;
extern unsigned short int  AD_Value[];

#endif
