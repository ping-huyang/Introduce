#include "key.h"
								    
/*************************************************************************************
* @note    : �������� 
* @note    : none 
* @note    : none 
* @note    : none
* @time     : 2023/05/27 15:53:59
*************************************************************************************/
void KEY_Init(void) //IO��ʼ��
{ 
 	GPIO_InitTypeDef GPIO_InitStructure;
 	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);//ʹ��PORTBʱ��
	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_2|GPIO_Pin_5|GPIO_Pin_7|GPIO_Pin_11|GPIO_Pin_12;//KEY1-KEY4
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
 	GPIO_Init(GPIOA, &GPIO_InitStructure);
}


/**
* @brief    : ������������ 
* @param    : mode:0,��֧��������;1,֧��������;
* @return   : ���ذ���ֵ��1~5  , �ް������·��� 0
* @author   : HuYang
* @note     : 2023/05/27 15:38:33
**/
u8 keyNum = 0;
u8 KEY_Scan(u8 mode)
{	 
	static u8 key_up=1;//�������ɿ���־
	if(mode)key_up=1;  //֧������	
	if(key_up&&(KEY1==0||KEY2==0||KEY3==0||KEY4==0||KEY5==0))
	{
		delay_ms(20);
		key_up=0;
		if(KEY5==0)return KEY5_PRES;
		else if(KEY1==0)return KEY1_PRES;
		else if(KEY2==0)return KEY2_PRES;
		else if(KEY3==0)return KEY3_PRES;
        else if(KEY4==0)return KEY4_PRES;
	}else if(KEY1==1&&KEY2==1&&KEY3==1&&KEY4==1&&KEY5==1)key_up=1; 	    
 	return 0;
}

/*************************************************************************************
* @note    : �����ǰ������º�Ļص����� 
* @note    : none 
* @note    : none 
* @note    : none
* @time     : 2023/04/20 08:11:20
*************************************************************************************/

void func1(void)
{
    PID_Variable_Clear();
    PID.Begain_Smooth = 1 - PID.Begain_Smooth;
    printf("Key1 was clicked \r\n");
}

void func2(void)
{
    Serial_Display_Variable();
}

void func3(void)
{
    OLED_PageAdd();
    printf("Key3 was clicked \r\n");
}

void func4(void)
{
    OLED_PageReduce();
    printf("Key4 was clicked \r\n");
}

void func5(void)
{
    LQR_Variable_Clear();
    static uint8_t Count;
    Count = 1 - Count;
    if(Count) LQR.Begain = 1;
        else LQR.Begain = 0;
    printf("func5 was called \r\n");
}

KeyFuncPtr keyFuncs[] = {func1, func2, func3, func4, func5};

