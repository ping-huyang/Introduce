/*************************************************************************************
* @note    : 保存代码片段 
* @note    : none 
* @note    : none 
* @note    : none
* @time     : 2023/05/08 17:37:54
*************************************************************************************/

// /**
// * @brief    : Timer1定时器初始化和中断处理函数 
// * @param    : none 
// * @return   : none 
// * @author   : HuYang
// * @note     : 2023/05/08 17:38:37
// **/

// TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
// NVIC_InitTypeDef NVIC_InitStructure2;
// RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);
// TIM_TimeBaseStructure.TIM_Period = 50 - 1;    
// TIM_TimeBaseStructure.TIM_Prescaler = 7200 - 1;
// TIM_TimeBaseStructure.TIM_ClockDivision = 0;
// TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
// TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;
// TIM_TimeBaseInit(TIM1, &TIM_TimeBaseStructure);
// TIM_ClearFlag(TIM1, TIM_FLAG_Update);
// TIM_ITConfig(TIM1,TIM_IT_Update|TIM_IT_Trigger, ENABLE);
// NVIC_InitStructure2.NVIC_IRQChannel = TIM1_UP_IRQn;  
// NVIC_InitStructure2.NVIC_IRQChannelPreemptionPriority = 0;
// NVIC_InitStructure2.NVIC_IRQChannelSubPriority = 0;  	  
// NVIC_InitStructure2.NVIC_IRQChannelCmd = ENABLE;
// NVIC_Init(&NVIC_InitStructure2); 
// TIM_Cmd(TIM1, ENABLE);  

// void TIM1_UP_IRQHandler(void)
// {
// 	if (TIM_GetITStatus(TIM1, TIM_IT_Update) != RESET) 
//     {  
//         TIM_ClearITPendingBit(TIM1, TIM_IT_Update);  //清除TIMx更新中断标志 
//     }
// }


// /**
// * @brief    : 位置pid控制 
// * @param    : none 
// * @return   : none 
// * @author   : HuYang
// * @note     : 2023/05/08 17:39:17
// **/

// Position1_PID.input = 0;
// Position1_PID.output = 0;
// Position1_PID.kp = POSITION1_INIT_KP;
// Position1_PID.ki = POSITION1_INIT_KI;
// Position1_PID.kd = POSITION1_INIT_KD;
// Position1_PID.NoWork_area = POSITION1_NOWORK_AREA;

// /**
// * @brief    : 外部调用修改位置 
// * @param    : setPosition：目标位置 
// * @return   : none 
// * @author   : HuYang
// * @note     : 2023/04/22 15:56:37
// **/
// void Set_Position(int16_t setPosition)
// {
//     // 最大移动限制
//     static int16_t max_Position = 1500;
//     if(setPosition > max_Position)
//         setPosition = max_Position;
//     if(setPosition < -max_Position)
//         setPosition = -max_Position;
//     Position1_PID.error = 0;
//     Position1_PID.lastError = 0;
//     Position1_PID.lastlastError = 0;
//     Position1_PID.input = setPosition;
// }


// /**
// * @brief    : 位置闭环控制 
// * @param    : 设定的位置坐标 [0 , 4000] 
// * @return   : 返回电机PWM值 
// * @author   : HuYang
// * @note     : 2023/04/22 11:10:42
// **/
// int32_t Position_CloseLoop(int16_t input)
// {
//     // static float Position_Least;
//     Position1_PID.feedback = Position_Encoder;
//     Position1_PID.error = input - Position1_PID.feedback;

//     if((Position1_PID.error > POSITION1_NOWORK_AREA) || (Position1_PID.error < -POSITION1_NOWORK_AREA)){
//         Position1_PID.output += -Position1_PID.kp*(Position1_PID.error-Position1_PID.lastError) - Position1_PID.ki*Position1_PID.error - Position1_PID.kd*(Position1_PID.error - 2*Position1_PID.lastError + Position1_PID.lastlastError);
//     }
//     Position1_PID.lastError = Position1_PID.error;
//     Position1_PID.lastlastError = Position1_PID.lastError;

//     if(Position1_PID.output > MOTOR_PWM_MAX)
//         Position1_PID.output = MOTOR_PWM_MAX;
//     if(Position1_PID.output < -MOTOR_PWM_MAX)
//         Position1_PID.output = -MOTOR_PWM_MAX;
//     return Position1_PID.output;
// }


// /**
// * @brief    : 一阶倒立摆自起摆控制，放在20ms定时中断里面执行，通过变量控制是否起动
// * @param    : none 
// * @return   : none 
// * @author   : HuYang
// * @note     : 2023/04/26 21:05:07
// **/
// void Automatic_Control(void)
// {
//     static int16_t last_Angle,dAngle,dir,state = 0;
//     dAngle = Angle_average - last_Angle;
//     last_Angle = Angle_average;
//     if(dAngle > 5 && dAngle < 20){
//         dir = 1;
//     }else if(dAngle > -20 && dAngle < -5){
//         dir = -1;
//     }

//     if(Angle_average > 2500 && Angle_average < 3000) state = 1;

//     if(dir == 1){
//         // 摆杆到达左边最高点，电机向右移动（-）
//         if(!state) Set_Position(-300);
//         if(state == 1) Set_Position(-50);
//     }else if(dir == -1){
//         //摆杆到达右边最高点，电机向左移动（+）
//         if(!state) Set_Position(300);
//         if(state == 1) Set_Position(50);
//     }

//     if((Angle_average > (ANGLE_INIT_CONTROL_POSITION - 200)) && (Angle_average < (ANGLE_INIT_CONTROL_POSITION + 200)))
//     {
//         Control_Clear();
//         Control_State.Pid_Begain = 1;
//         Control_State.Auto_Begain = 0;
//     }else{
//         MOTOR_SetPwmValue(Position_CloseLoop(Position1_PID.input));
//     }
// }



